#!/bin/bash

/usr/bin/bash /home/ec2-user/malsy/shell/malsy_iics_command_task.sh

exit 0