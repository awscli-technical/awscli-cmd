データファイルコピースクリプトの使用手順


■環境

▼関係AWSリソース
EC2インスタンス：i-0ef3f89b3345b1dc6 (cfn-gamma-dev-ec2-instance-ap-northeast-1a-bastion-amazonlinux2023)
EC2インスタンス：i-0dd3c545e1e74c89a (cfn-gamma-dev-ec2-instance-ap-northeast-1a-bastion-windowsserver2022)
S3バケット：s3://cfn-gamma-dev-s3-bucket-malsy-049229311148/csv/mon/

▼IICSコマンドタスク実行用スクリプト
sudo -u ec2-user "/home/ec2-user/malsy/shell/malsy_iics_command_task.sh"

▼IICSタスクフロー実行用スクリプト
sudo -u ec2-user "/home/ec2-user/malsy/shell/malsy_iics_task_flow.sh"


■資材配置手順

①シェルスクリプトの配置(Amazon Linux 2023)

sudo su -
su - ec2-user
/home/ec2-user/malsy/shell/malsy_iics_command_task.sh
/home/ec2-user/malsy/shell/malsy_iics_task_flow.sh

②配置先ディレクトリの作成(Windows Server 2022)

New-Item -Path "C:\Temp\Data" -ItemType Directory -Force

③-1データファイルコピースクリプトの実行（i-0ef3f89b3345b1dc6にログインして実行する場合）

sudo su -
su - ec2-user

IICSコマンドタスク実行用スクリプトの場合
/home/ec2-user/malsy/shell/malsy_iics_command_task.sh

IICSタスクフロー実行用スクリプトの場合
/home/ec2-user/malsy/shell/malsy_iics_task_flow.sh

③-2データファイルコピースクリプトの実行（AWS Systems Manager Run Command で実行する場合）

AWS Systems Manager > Run Command
	[Run command]ボタンを押下
		コマンドの実行 > コマンドドキュメント > [AWS-RunShellScript]を検索して選択
			コマンドのパラメータ > [sudo -u ec2-user "/home/ec2-user/malsy/shell/malsy_iics_command_task.sh"]を入力
				ターゲット > [インスタンスを手動で選択する]を選択
					インスタンス > [cfn-gamma-dev-ec2-instance-ap-northeast-1a-bastion-amazonlinux2023]を選択
						[実行]ボタンを押下

	コマンド ID: 693f9869-9ed4-42f6-937d-2078aecea071
		ターゲットと出力 > インスタンス ID[i-0ef3f89b3345b1dc6]のリンクをクリック

	出力先 i-0ef3f89b3345b1dc6
		ステップ 1 - コマンドの説明とステータス
			Outputを展開してスクリプトログの出力結果を確認します。


AWS Systems Manager > Run Command
	[Run command]ボタンを押下
		コマンドの実行 > コマンドドキュメント > [AWS-RunShellScript]を検索して選択
			コマンドのパラメータ > [sudo -u ec2-user "/home/ec2-user/malsy/shell/malsy_iics_task_flow.sh"]を入力
				ターゲット > [インスタンスを手動で選択する]を選択
					インスタンス > [cfn-gamma-dev-ec2-instance-ap-northeast-1a-bastion-amazonlinux2023]を選択
						[実行]ボタンを押下

	コマンド ID: 693f9869-9ed4-42f6-937d-2078aecea071
		ターゲットと出力 > インスタンス ID[i-0ef3f89b3345b1dc6]のリンクをクリック

	出力先 i-0ef3f89b3345b1dc6
		ステップ 1 - コマンドの説明とステータス
			Outputを展開してスクリプトログの出力結果を確認します。
