## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json --timeout 900
## lambda-uploader
import boto3
import os

client = boto3.client('workspaces')
sns = boto3.client('sns')

def lambda_handler(event, context):
    ## 環境変数の読み込み
    target_directory_id = os.environ.get('TARGET_DIRECTORY_ID', '')
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    sns_topic_arn       = os.environ.get('SNS_TOPIC_ARN', '')
    alarm_subject       = os.environ.get('ALARM_SUBJECT', '')
    print("TARGET_DIRECTORY_ID = " + target_directory_id)
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)
    print("SNS_TOPIC_ARN = " + sns_topic_arn)
    print("ALARM_SUBJECT = " + alarm_subject)

    workspaces_client_list = ""
    if target_directory_id == '':
        print("全てのWorkSpacesが対象です。")
        response = client.describe_workspaces()
        workspaces_client_list = response['Workspaces']
        while "NextToken" in response:
            workspaces_client_list.extend(response['Workspaces'])
            response = client.describe_workspaces(NextToken=response['NextToken'])
        #print(workspaces_client_list) ## Debug code
    else:
        print(target_directory_id + "配下のWorkSpacesが対象です。")
        response = client.describe_workspaces(DirectoryId=target_directory_id)
        workspaces_client_list = response['Workspaces']
        while "NextToken" in response:
            workspaces_client_list.extend(response['Workspaces'])
            response = client.describe_workspaces(NextToken=response['NextToken'])
        #print(workspaces_client_list) ## Debug code

    workspaces_target_list = []
    ## 全WorkSpacesを1台ずつ読み出し
    for workspace in workspaces_client_list:
        ## 対象状態WorkSpacesを1台ずつ読み出し
        if workspace.get('State') == 'STOPPED': ## Debug code
        #if workspace.get('State') == 'UNHEALTHY':
            #print(workspace) ## Debug code
            directory_id = workspace['DirectoryId']
            workspace_id = workspace['WorkspaceId']
            user_name = workspace['UserName']
            workspace_state = workspace['State']
            print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
            print("対象状態のWorkSpaces ............")
            print("DirectoryId:" + directory_id, "WorkspaceId:" + workspace_id, "UserName:" + user_name, "State:" + workspace_state)

            ## 対象状態WorkSpacesのタグ情報を読み出し
            workspaces_tag = client.describe_tags(ResourceId=workspace_id)
            print("対象状態WorkSpacesnoの全タグ ............")
            print(workspaces_tag)
            for tag in workspaces_tag.get('TagList'):
                ## タグ情報からタグリストを取得して対象タグが一致するものを配列に格納
                if (tag.get('Key') == target_tag_key) and (tag.get('Value') == target_tag_value):
                    workspaces_target_list.append(directory_id)
                    workspaces_target_list.append(workspace_id)
                    workspaces_target_list.append(user_name)
                    workspaces_target_list.append(workspace_state)
                    workspaces_target_list.append(tag.get('Key'))
                    workspaces_target_list.append(tag.get('Value'))
                    print("対象状態で且つ、対象タグを保持しているWorkSpaces ............")
                    print("DirectoryId:" + directory_id, "WorkspaceId:" + workspace_id, "UserName:" + user_name, "State:" + workspace_state, "target_tag_key:" + tag.get('Key'), "target_tag_value:" + tag.get('Value'))
                    rc = start_workspaces(workspace_id)
                    if rc == 0:
                        print('WorkSpace "{0}" started successfully.'.format(workspace_id))
                    else:
                        print('WorkSpace "{0}" tried to start, but an error occurred while starting.'.format(workspace_id))

            #print(workspaces_target_list) ## Debug code

    print("検査で特定されたWorkSpacesを表示します。")

    ## 通知メール本文の整形
    result = "DirectoryId,WorkspaceId,UserName,State,tagKey,tagValue\n"
    result += "-------------------------------------------------------\n"
    cnt = 0
    workspaces_num = 0
    ## 配列には対象状態で且つ、対象タグを保持しているWorkSpacesが格納されています。
    ## 配列要素をWorkSpaces1台単位で切り出してresultに代入していきます。
    for item in workspaces_target_list:
        sep = ',' ## セパレーター(,)
        result += item + sep
        cnt += 1
        ## 配列要素0-4,5-9・・・ごとに改行コードを挿入
        if cnt == 6:
            new_line = '\n'
            result = result[:-len(sep)] ## 改行する行の最後尾のカンマ(,)を除去
            result += new_line
            cnt = 0
            workspaces_num += 1

    result += "検査で特定され再起動されたWorkSpacesの合計数:" + str(workspaces_num)
    print(result)

    ## 検査で特定されたWorkSpacesが存在し再起動した場合はメール通知します。
    if workspaces_num != 0:
        ## 通知設定
        massages = {
            'TopicArn': sns_topic_arn,
            'Subject': alarm_subject,
            'Message': result
        }
        print("検査で特定されたWorkSpacesが存在し再起動したためメール通知します。")
        sns.publish(**massages)

    ## 戻り値
    return workspaces_target_list

## 対象WorkSpacesの再起動
def start_workspaces(workspace_id):
    execution_result = client.start_workspaces(
        StartWorkspaceRequests = [
            {
                'WorkspaceId': workspace_id
            },
        ]
    )
    failed_requests = execution_result.get('FailedRequests')
    if not failed_requests:
        return 0
    else:
        print('[Error] {0}'.format(failed_requests))
        return 1
