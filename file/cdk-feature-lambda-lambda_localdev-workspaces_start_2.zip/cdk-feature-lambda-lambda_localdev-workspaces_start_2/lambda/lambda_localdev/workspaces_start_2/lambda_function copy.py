## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json
## lambda-uploader
import boto3
import os

client = boto3.client('workspaces')

def lambda_handler(event, context):
    target_directory_id = os.environ.get('TARGET_DIRECTORY_ID', '')
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    print("TARGET_DIRECTORY_ID = " + target_directory_id)
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)

    if target_directory_id == '':
        print("debug1")
        response = client.describe_workspaces()
    else:
        print("debug2")
        response = client.describe_workspaces(DirectoryId=target_directory_id)

    all_list = []
    for workspace in response['Workspaces']:

        directory_id = workspace['DirectoryId']
        workspace_id = workspace['WorkspaceId']
        workspace_state = workspace['State']

        print("DirectoryId:" + directory_id, "WorkspaceId:" + workspace_id, "State:" + workspace_state)

        tag_flg = False
        response = client.describe_tags(ResourceId=workspace_id)

        for tag in response.get('TagList'):
            if (tag.get('Key') == target_tag_key) and (tag.get('Value') == target_tag_value):
                tag_flg = True
            
            if tag_flg == False:
                continue

            if workspace.get('State') == 'STOPPED':
                all_list.append(workspace_id)
                all_list.append(workspace_state)
                all_list.append(tag.get('Key'))
                all_list.append(tag.get('Value'))
                print(all_list)
                rc = start_workspaces(workspace_id)
                if rc == 0:
                    print('WorkSpace "{0}" started successfully.'.format(workspace_id))
                else:
                    print('WorkSpace "{0}" tried to start, but an error occurred while starting.'.format(workspace_id))

def start_workspaces(workspace_id):
    result = client.start_workspaces(
        StartWorkspaceRequests = [
            {
                'WorkspaceId': workspace_id
            },
        ]
    )
    failed_requests = result.get('FailedRequests')
    if not failed_requests:
        return 0
    else:
        print('[Error] {0}'.format(failed_requests))
        return 1
