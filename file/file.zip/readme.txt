AWS CLI AWSバックアップの使用手順


■動作環境
■資材
■実行方法
■実行時ログの確認方法




■動作環境

Windows + Cygwin + AWS CLI


■資材

PS C:\work\local\download\定期保守作業自動化\shells> tree /A /F ./
フォルダー パスの一覧:  ボリューム Windows
ボリューム シリアル番号は 8275-144C です
C:\WORK\LOCAL\DOWNLOAD\定期保守作業自動化\SHELLS
|   tree
|   unyo_accountid_aws_backup.sh
|   unyo_accountid_ctl_ec2_instance.sh
|
+---log
|       unyo_accountid_aws_backup_20251031-205456.log
|       unyo_accountid_ctl_ec2_instance_20251031-222755.log
|
\---lst
        unyo_accountid_backup.lst
        unyo_accountid_ec2_instance.lst


■実行方法

前提条件) AWS認証がされていること

①Cygwinを起動します。
②資材の配置箇所に移動します。
例) cd /cygdrive/c/work/local/download/定期保守作業自動化/shells
④バックアップを実行します。
./unyo_accountid_aws_backup.sh unyo_accountid_backup.lst


■実行時ログの確認方法

2025/10/31 20:54:57 [thirdwave01] リストファイルの存在が確認できました。
2025/10/31 20:54:57 [thirdwave01] 作業環境を確認してください。
{
    "UserId": "AROAQW5SLVSWNZ364EHLN:sso",
    "Account": "049229311148",
    "Arn": "arn:aws:sts::049229311148:assumed-role/AWSReservedSSO_AdministratorAccess_371ebe03403642b3/sso"
}

Region: ap-northeast-1

2025/10/31 20:55:07 [thirdwave01] バックアップ対象リソースを確認してください。
resource=ec2
backup_vault_name=cfn-gamma-dev-backup-vault-ec2
resource_arn=arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0ef3f89b3345b1dc6
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

resource=ec2
backup_vault_name=cfn-gamma-dev-backup-vault-ec2
resource_arn=arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0b304c62120dc2f10
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

resource=efs
backup_vault_name=cfn-gamma-dev-backup-vault-efs
resource_arn=arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-0e7f825279f46d682
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

resource=efs
backup_vault_name=cfn-gamma-dev-backup-vault-efs
resource_arn=arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-064ec78ebed4f24a8
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

resource=rds
backup_vault_name=cfn-gamma-dev-backup-vault-rds
resource_arn=arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

resource=rds
backup_vault_name=cfn-gamma-dev-backup-vault-rds
resource_arn=arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance-plus-1
iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
delete_after_days=60
region=ap-northeast-1

2025/10/31 20:55:23 [thirdwave01] unyo_accountid_aws_backup.sh の全体処理を開始します。
2025/10/31 20:55:23 [thirdwave01] バックアップジョブを開始します。
2025/10/31 20:55:24 [thirdwave01] resource=ec2
2025/10/31 20:55:24 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-ec2
2025/10/31 20:55:24 [thirdwave01] resource_arn=arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0ef3f89b3345b1dc6
2025/10/31 20:55:24 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:24 [thirdwave01] delete_after_days=60
2025/10/31 20:55:24 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:24 [thirdwave01] 1 件目のジョブが開始されました。

2025/10/31 20:55:25 [thirdwave01] resource=ec2
2025/10/31 20:55:25 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-ec2
2025/10/31 20:55:25 [thirdwave01] resource_arn=arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0b304c62120dc2f10
2025/10/31 20:55:25 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:26 [thirdwave01] delete_after_days=60
2025/10/31 20:55:26 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:26 [thirdwave01] 2 件目のジョブが開始されました。

2025/10/31 20:55:27 [thirdwave01] resource=efs
2025/10/31 20:55:27 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-efs
2025/10/31 20:55:27 [thirdwave01] resource_arn=arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-0e7f825279f46d682
2025/10/31 20:55:27 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:27 [thirdwave01] delete_after_days=60
2025/10/31 20:55:27 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:27 [thirdwave01] 3 件目のジョブが開始されました。

2025/10/31 20:55:28 [thirdwave01] resource=efs
2025/10/31 20:55:28 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-efs
2025/10/31 20:55:28 [thirdwave01] resource_arn=arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-064ec78ebed4f24a8
2025/10/31 20:55:28 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:28 [thirdwave01] delete_after_days=60
2025/10/31 20:55:28 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:28 [thirdwave01] 4 件目のジョブが開始されました。

2025/10/31 20:55:30 [thirdwave01] resource=rds
2025/10/31 20:55:30 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-rds
2025/10/31 20:55:30 [thirdwave01] resource_arn=arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance
2025/10/31 20:55:30 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:30 [thirdwave01] delete_after_days=60
2025/10/31 20:55:30 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:30 [thirdwave01] 5 件目のジョブが開始されました。

2025/10/31 20:55:31 [thirdwave01] resource=rds
2025/10/31 20:55:31 [thirdwave01] backup_vault_name=cfn-gamma-dev-backup-vault-rds
2025/10/31 20:55:31 [thirdwave01] resource_arn=arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance-plus-1
2025/10/31 20:55:31 [thirdwave01] iam_role_arn=arn:aws:iam::049229311148:role/service-role/cfn-gamma-dev-iam-role-backup
2025/10/31 20:55:31 [thirdwave01] delete_after_days=60
2025/10/31 20:55:31 [thirdwave01] region=ap-northeast-1
2025/10/31 20:55:31 [thirdwave01] 6 件目のジョブが開始されました。

2025/10/31 20:55:31 [thirdwave01] 開始されたジョブID一覧
2025/10/31 20:55:31 [thirdwave01] ba5991c8-1dac-46a6-b055-be3687b83115
2025/10/31 20:55:31 [thirdwave01] 28e15be1-b4aa-4aed-8e65-c6d04e3bd867
2025/10/31 20:55:31 [thirdwave01] f734ca4b-3265-49b6-9ad6-bcb30718631d
2025/10/31 20:55:31 [thirdwave01] a530f06d-f899-4c55-9add-143be7fda894
2025/10/31 20:55:31 [thirdwave01] a4aa0671-55c8-4057-ba62-3945c0296354
2025/10/31 20:55:31 [thirdwave01] 767ba40d-3477-46d8-807a-1fa85cafcfdd
2025/10/31 20:55:31 [thirdwave01] 合計 6 件のジョブが開始されました。
2025/10/31 20:55:32 [thirdwave01] 全てのジョブが完了するまで待機します。
2025/10/31 20:55:33 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は RUNNING
2025/10/31 20:55:34 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 20:55:35 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 20:55:36 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は RUNNING
2025/10/31 20:55:37 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は RUNNING
2025/10/31 20:55:38 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 20:56:38 [thirdwave01] ここまでの待ち時間合計：1 minutes
2025/10/31 20:56:39 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は RUNNING
2025/10/31 20:56:40 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 20:56:41 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 20:56:42 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 20:56:43 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は RUNNING
2025/10/31 20:56:44 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 20:57:44 [thirdwave01] ここまでの待ち時間合計：2 minutes
2025/10/31 20:57:45 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 20:57:46 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 20:57:47 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 20:57:49 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 20:57:50 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 20:57:51 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 20:58:51 [thirdwave01] ここまでの待ち時間合計：3 minutes
2025/10/31 20:58:52 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 20:58:53 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 20:58:54 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 20:58:55 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 20:58:56 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 20:58:57 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 20:59:57 [thirdwave01] ここまでの待ち時間合計：4 minutes
2025/10/31 20:59:58 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 20:59:59 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 21:00:01 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 21:00:02 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 21:00:03 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 21:00:04 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 21:01:04 [thirdwave01] ここまでの待ち時間合計：5 minutes
2025/10/31 21:01:05 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 21:01:06 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 21:01:07 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 21:01:08 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 21:01:09 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 21:01:10 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 21:02:10 [thirdwave01] ここまでの待ち時間合計：6 minutes
2025/10/31 21:02:11 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 21:02:12 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 21:02:13 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 21:02:14 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 21:02:15 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 21:02:17 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 21:03:17 [thirdwave01] ここまでの待ち時間合計：7 minutes
2025/10/31 21:03:18 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 21:03:19 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は RUNNING
2025/10/31 21:03:20 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 21:03:21 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 21:03:22 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 21:03:23 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は RUNNING
2025/10/31 21:04:23 [thirdwave01] ここまでの待ち時間合計：8 minutes
2025/10/31 21:04:24 [thirdwave01] ジョブID：ba5991c8-1dac-46a6-b055-be3687b83115 は COMPLETED
2025/10/31 21:04:25 [thirdwave01] ジョブID：28e15be1-b4aa-4aed-8e65-c6d04e3bd867 は COMPLETED
2025/10/31 21:04:26 [thirdwave01] ジョブID：f734ca4b-3265-49b6-9ad6-bcb30718631d は COMPLETED
2025/10/31 21:04:27 [thirdwave01] ジョブID：a530f06d-f899-4c55-9add-143be7fda894 は COMPLETED
2025/10/31 21:04:28 [thirdwave01] ジョブID：a4aa0671-55c8-4057-ba62-3945c0296354 は COMPLETED
2025/10/31 21:04:29 [thirdwave01] ジョブID：767ba40d-3477-46d8-807a-1fa85cafcfdd は COMPLETED
2025/10/31 21:04:29 [thirdwave01] 全てのジョブが完了しました。
2025/10/31 21:04:30 [thirdwave01] cfn-gamma-dev-backup-vault-ec2 バックアップのリカバリポイント情報を表示します。
[
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-ec2",
        "ResourceArn": "arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0b304c62120dc2f10",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:25.606000+01:00",
        "CompletionDate": "2025-10-31T13:03:36.261000+01:00",
        "BackupSizeInBytes": 32212254720,
        "DeleteAfterDays": 60
    },
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-ec2",
        "ResourceArn": "arn:aws:ec2:ap-northeast-1:049229311148:instance/i-0ef3f89b3345b1dc6",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:24.286000+01:00",
        "CompletionDate": "2025-10-31T12:57:28.926000+01:00",
        "BackupSizeInBytes": 8589934592,
        "DeleteAfterDays": 60
    }
]
2025/10/31 21:04:31 [thirdwave01] cfn-gamma-dev-backup-vault-efs バックアップのリカバリポイント情報を表示します。
[
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-efs",
        "ResourceArn": "arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-064ec78ebed4f24a8",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:28.330000+01:00",
        "CompletionDate": "2025-10-31T12:55:36.753000+01:00",
        "BackupSizeInBytes": 72,
        "DeleteAfterDays": 60
    },
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-efs",
        "ResourceArn": "arn:aws:elasticfilesystem:ap-northeast-1:049229311148:file-system/fs-0e7f825279f46d682",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:26.949000+01:00",
        "CompletionDate": "2025-10-31T12:55:34.258000+01:00",
        "BackupSizeInBytes": 116,
        "DeleteAfterDays": 60
    }
]
2025/10/31 21:04:32 [thirdwave01] cfn-gamma-dev-backup-vault-rds バックアップのリカバリポイント情報を表示します。
[
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-rds",
        "ResourceArn": "arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance-plus-1",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:31.328000+01:00",
        "CompletionDate": "2025-10-31T13:03:34.253000+01:00",
        "BackupSizeInBytes": 0,
        "DeleteAfterDays": 60
    },
    {
        "BackupVaultName": "cfn-gamma-dev-backup-vault-rds",
        "ResourceArn": "arn:aws:rds:ap-northeast-1:049229311148:db:cfn-gamma-dev-rds-database-instance",
        "Status": "COMPLETED",
        "CreationDate": "2025-10-31T12:55:29.862000+01:00",
        "CompletionDate": "2025-10-31T12:57:31.423000+01:00",
        "BackupSizeInBytes": 0,
        "DeleteAfterDays": 60
    }
]
2025/10/31 21:04:33 [thirdwave01] unyo_accountid_aws_backup.sh の全体処理が成功しました。
