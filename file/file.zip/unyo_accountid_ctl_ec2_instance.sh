#!/bin/bash
####################################################################################################
#    機能          :  EC2インスタンス制御
#                     停止）
#                     リストに記載したEC2インスタンスIDに対して停止します。
#                     EC2インスタンス停止に失敗した場合は異常終了します。
#                     起動）
#                     リストに記載したEC2インスタンスIDに対して起動します。
#                     EC2インスタンス起動に失敗した場合は異常終了します。
#                     状態確認)
#                     EC2インスタンス状態表示
#                     リストに記載したEC2インスタンスIDに対して状態表示します。
#
#    ファイル名    :  unyo_accountid_ctl_ec2_instance.sh
#    作成者        :
#    作成日        :  2025/10/31
#    備考          :  AWSアカウントにログイン後に本スクリプトを実行する必要があります。
#    変更履歴      :
#
#    引数          :  $1(stop/start/status)
#                  :  $2(unyo_accountid_ec2_instance.lst)
#    戻り値        :  0(正常)
#                  :  1(異常)
####################################################################################################
##################################################
# 変数定義
##################################################
#-------------------------------------------------
# 日付
#-------------------------------------------------
DATE="$(date "+%Y%m%d")"

#-------------------------------------------------
# ホスト名
#-------------------------------------------------
HOST_NAME="$(uname -n)"

#-------------------------------------------------
# スクリプト名
#-------------------------------------------------
SCRIPT_NAME="$(basename $0 .sh)"

#-------------------------------------------------
# ログファイル
#-------------------------------------------------
LOG_DATE="$(date "+%Y%m%d-%H%M%S")"
LOG_PATH="log"
LOG="$(echo ${LOG_PATH}/${SCRIPT_NAME}_${LOG_DATE}.log)"

##################################################
# 前処理
##################################################
#-------------------------------------------------
# ディレクトリ作成
#-------------------------------------------------
mkdir -p ${LOG_PATH}

#-------------------------------------------------
# 引数取得
#-------------------------------------------------
# EC2インスタンスの制御種別
CTL=$1
# リストファイル存在確認
if [[ ${CTL} = "stop" || ${CTL} = "start" || ${CTL} = "status" ]]; then
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 制御種別は [${CTL}] が指定されました。" 2>&1 | tee -a "${LOG}"
else
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 制御種別は stop/start/status を指定してください。" 2>&1 | tee -a "${LOG}"
    # 異常終了
    exit 1
fi

# リストファイル取得
LIST_FILE=$2
LIST="lst/${LIST_FILE}"
echo "LIST=${LIST}"

# リストファイル存在確認
if [[ -f "${LIST}" ]]; then
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] リストファイルの存在が確認できました。" 2>&1 | tee -a "${LOG}"
else
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] リストファイルの存在が確認できませんでした。" 2>&1 | tee -a "${LOG}"
    # 異常終了
    exit 1
fi

#-------------------------------------------------
# 引数が正しく設定されている場合はyesを入力して処理を続行
# 正しくない場合はnoを入力して処理を中断
# 入力ミスした場合は異常終了
#-------------------------------------------------
read -p "処理を続行しますか？ (yes/no): " answer
case "$answer" in
    yes|YES|y|Y)
        echo "処理を続行します..."
        ;;
    no|NO|n|N)
        echo "処理を中止します。"
        exit 0
        ;;
    *)
        echo "yes か no を入力してください。"
        exit 1
        ;;
esac

#-------------------------------------------------
# 作業環境確認
#-------------------------------------------------
#-------------------------------------------------
# AWSアカウントIDの表示
# IAMロールの表示
# ユーザIDの表示
# リージョンの表示
#-------------------------------------------------
aws sts get-caller-identity 2>&1 | tee -a "${LOG}"

region=$(aws configure get region)
echo "Region: $region"  2>&1 | tee -a "${LOG}"

#-------------------------------------------------
# 作業リソースを目視確認して正しく設定されている場合はyesを入力して処理を続行
# 正しくない場合はnoを入力して処理を中断
# 入力ミスした場合は異常終了
#-------------------------------------------------
read -p "処理を続行しますか？ (yes/no): " answer
case "$answer" in
    yes|YES|y|Y)
        echo "処理を続行します..."
        ;;
    no|NO|n|N)
        echo "処理を中止します。"
        exit 0
        ;;
    *)
        echo "yes か no を入力してください。"
        exit 1
        ;;
esac

#-------------------------------------------------
# 作業リソース確認
#-------------------------------------------------
#-------------------------------------------------
# EC2インスタンスIDの表示
# EC2インスタンスタグ(Key=Name)の表示
#-------------------------------------------------
while IFS= read -r instance_id
do
    # 前後のタブ・空白・改行を削除
    instance_id="${instance_id//[$'\t\r\n ']/}"
    aws ec2 describe-instances \
        --instance-ids $instance_id \
        --query 'Reservations[].Instances[].{
            InstanceId: InstanceId,
            InstanceState: State.Name,
            Name: Tags[?Key==`Name`]|[0].Value
        }' 2>&1 | tee -a "${LOG}"
        # --output table
done < "${LIST}"

#-------------------------------------------------
# 作業リソースを目視確認して正しく設定されている場合はyesを入力して処理を続行
# 正しくない場合はnoを入力して処理を中断
# 入力ミスした場合は異常終了
#-------------------------------------------------
read -p "処理を続行しますか？ (yes/no): " answer
case "$answer" in
    yes|YES|y|Y)
        echo "処理を続行します..."
        ;;
    no|NO|n|N)
        echo "処理を中止します。"
        exit 0
        ;;
    *)
        echo "yes か no を入力してください。"
        exit 1
        ;;
esac

##################################################
# 主処理
##################################################
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${SCRIPT_NAME}.sh の全体処理を開始します。" 2>&1 | tee -a "${LOG}"

#-------------------------------------------------
# EC2インスタンス制御
#-------------------------------------------------
case "${CTL}" in
    #-------------------------------------------------
    # EC2インスタンス停止
    #-------------------------------------------------
    stop)
        while IFS= read -r instance_id
        do
            # 前後のタブ・空白・改行を削除
            instance_id="${instance_id//[$'\t\r\n ']/}"
            echo "aws ec2 stop-instances --instance-ids $instance_id" 2>&1 | tee -a "${LOG}"
            aws ec2 stop-instances --instance-ids $instance_id 2>&1 | tee -a "${LOG}"
            # echo PIPESTATUS=${PIPESTATUS[@]} # debug rc
            CMD_RC=${PIPESTATUS[0]}
            # echo CMD_RC=${CMD_RC} # debug rc
            if [[ "${CMD_RC}" != 0 ]]; then
                echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] EC2インスタンス（$instance_id）の停止が失敗しました。" 2>&1 | tee -a "${LOG}"
                # 異常終了
                exit 1
            fi
        done < "${LIST}"
        ;;
    #-------------------------------------------------
    # EC2インスタンス起動
    #-------------------------------------------------
    start)
        while IFS= read -r instance_id
        do
            # 前後のタブ・空白・改行を削除
            instance_id="${instance_id//[$'\t\r\n ']/}"
            echo "aws ec2 start-instances --instance-ids $instance_id" 2>&1 | tee -a "${LOG}"
            aws ec2 start-instances --instance-ids $instance_id 2>&1 | tee -a "${LOG}"
            # echo PIPESTATUS=${PIPESTATUS[@]} # debug rc
            CMD_RC=${PIPESTATUS[0]}
            # echo CMD_RC=${CMD_RC} # debug rc
            if [[ "${CMD_RC}" != 0 ]]; then
                echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] EC2インスタンス（$instance_id）の起動が失敗しました。" 2>&1 | tee -a "${LOG}"
                # 異常終了
                exit 1
            fi
        done < "${LIST}"
        ;;
    #-------------------------------------------------
    # EC2インスタンス状態表示
    #-------------------------------------------------
    status)
        while IFS= read -r instance_id
        do
            # 前後のタブ・空白・改行を削除
            instance_id="${instance_id//[$'\t\r\n ']/}"
            echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] EC2インスタンス（$instance_id）の InstanceState および InstanceStatus/SystemStatus を表示します。" 2>&1 | tee -a "${LOG}"
            # InstanceState の表示
            aws ec2 describe-instances \
                --instance-ids $instance_id \
                --query 'Reservations[].Instances[].{
                    InstanceId: InstanceId,
                    InstanceState: State.Name,
                    Name: Tags[?Key==`Name`]|[0].Value
                }' \
                --output table 2>&1 | tee -a "${LOG}"
            # InstanceStatus SystemStatus の表示
            aws ec2 describe-instance-status \
                --include-all-instances \
                --instance-ids $instance_id \
                --query 'InstanceStatuses[].{
                    InstanceId: InstanceId,
                    InstanceState: InstanceState.Name,
                    InstanceStatus: InstanceStatus.Status,
                    SystemStatus: SystemStatus.Status
                }' \
                --output table 2>&1 | tee -a "${LOG}"
            echo "" 2>&1 | tee -a "${LOG}"
            echo "" 2>&1 | tee -a "${LOG}"
        done < "${LIST}"
        ;;
esac

##################################################
# 後処理
##################################################
# 正常終了
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${SCRIPT_NAME}.sh の全体処理が成功しました。" 2>&1 | tee -a "${LOG}"
exit 0
