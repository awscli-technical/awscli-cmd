#!/bin/bash
####################################################################################################
#    機能          :  AWS Backupジョブ開始・状態確認
#                     引数ファイルに記載したAWSリソースに対してバックアップ取得します。
#                     バックアップに失敗した場合は異常終了します。
#                     作業環境・リソースの確認時に入力値を間違えると異常終了します。
#                     作業環境・リソースの確認時に入力値(yes)の場合は処理を続行します。
#                     作業環境・リソースの確認時に入力値(no)の場合は処理を中止します。
#
#    ファイル名    :  unyo_accountid_aws_backup.sh
#    作成者        :
#    作成日        :  2025/10/31
#    備考          :  AWSアカウントにログイン後に本スクリプトを実行する必要があります。
#    変更履歴      :
#
#    使用方法      :  ./unyo_accountid_aws_backup.sh unyo_accountid_backup.lst
#    引数          :  unyo_accountid_backup.lst
#    戻り値        :  0(正常)
#                  :  1(異常)
####################################################################################################
##################################################
# 変数定義
##################################################
#-------------------------------------------------
# 日付
#-------------------------------------------------
DATE="$(date "+%Y%m%d")"

#-------------------------------------------------
# ホスト名
#-------------------------------------------------
HOST_NAME="$(uname -n)"

#-------------------------------------------------
# スクリプト名
#-------------------------------------------------
SCRIPT_NAME="$(basename $0 .sh)"

#-------------------------------------------------
# ログファイル
#-------------------------------------------------
LOG_DATE="$(date "+%Y%m%d-%H%M%S")"
LOG_PATH="log"
LOG="$(echo ${LOG_PATH}/${SCRIPT_NAME}_${LOG_DATE}.log)"

##################################################
# 関数定義
##################################################
#-------------------------------------------------
# 関数名  :  リカバリーポイント表示
# 機能    :  本スクリプトで取得したバックアップのリカバリポイントを表示します。
# 引数    :  $1(バックアップ件数)
#            $2(バックアップボールト)
#-------------------------------------------------
func_show_recovery_point(){
    cnt_rp=$1
    backup_vault_name=$2

    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $backup_vault_name バックアップのリカバリポイント情報を表示します。" 2>&1 | tee -a "${LOG}"
    aws backup list-recovery-points-by-backup-vault \
      --backup-vault-name $backup_vault_name \
      --query "reverse(sort_by(RecoveryPoints, &CreationDate))[:$cnt_rp].{
        BackupVaultName: BackupVaultName,
        ResourceArn: ResourceArn,
        Status: Status,
        CreationDate: CreationDate,
        CompletionDate: CompletionDate,
        BackupSizeInBytes: BackupSizeInBytes,
        DeleteAfterDays: Lifecycle.DeleteAfterDays
      }" 2>&1 | tee -a "${LOG}"
}

##################################################
# 前処理
##################################################
#-------------------------------------------------
# ログディレクトリ作成
#-------------------------------------------------
mkdir -p ${LOG_PATH}

#-------------------------------------------------
# リストファイル取得
#-------------------------------------------------
# リストファイル取得
LIST_FILE=$1
LIST="lst/${LIST_FILE}"
echo "LIST=${LIST}"

# リストファイル存在確認
if [[ -f "${LIST}" ]]; then
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] リストファイルの存在が確認できました。" 2>&1 | tee -a "${LOG}"
else
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] リストファイルの存在が確認できませんでした。" 2>&1 | tee -a "${LOG}"
    # 異常終了
    exit 1
fi

#-------------------------------------------------
# 作業環境確認
# AWSアカウントID、IAMロール、ユーザID、リージョン表示
# 作業リソースを目視確認して正しく設定されている場合はyesを入力して処理を続行
# 正しくない場合はnoを入力して処理を中断
# 入力ミスした場合は異常終了
#-------------------------------------------------
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 作業環境を確認してください。" 2>&1 | tee -a "${LOG}"
aws sts get-caller-identity 2>&1 | tee -a "${LOG}"
echo ""  2>&1 | tee -a "${LOG}"

region=$(aws configure get region)
echo "Region: $region"  2>&1 | tee -a "${LOG}"
echo ""  2>&1 | tee -a "${LOG}"

read -p "処理を続行しますか？ (yes/no): " answer
case "$answer" in
    yes|YES|y|Y)
        echo "処理を続行します..."
        ;;
    no|NO|n|N)
        echo "処理を中止します。"
        exit 0
        ;;
    *)
        echo "yes か no を入力してください。"
        exit 1
        ;;
esac

#-------------------------------------------------
# 作業リソース確認
# バックアップボールト、リソースARN、IAMロールARN、合計保持期間、リージョン表示
# 作業リソースを目視確認して正しく設定されている場合はyesを入力して処理を続行
# 正しくない場合はnoを入力して処理を中断
# 入力ミスした場合は異常終了
#-------------------------------------------------
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] バックアップ対象リソースを確認してください。" 2>&1 | tee -a "${LOG}"
while read -r resource backup_vault_name resource_arn iam_role_arn delete_after_days region
do
    # 前後のタブ・空白・改行を削除
    resource="${resource//[$'\t\r\n ']/}"
    backup_vault_name="${backup_vault_name//[$'\t\r\n ']/}"
    resource_arn="${resource_arn//[$'\t\r\n ']/}"
    iam_role_arn="${iam_role_arn//[$'\t\r\n ']/}"
    delete_after_days="${delete_after_days//[$'\t\r\n ']/}"
    region="${region//[$'\t\r\n ']/}"

    echo "resource=$resource" 2>&1 | tee -a "${LOG}"
    echo "backup_vault_name=$backup_vault_name" 2>&1 | tee -a "${LOG}"
    echo "resource_arn=$resource_arn" 2>&1 | tee -a "${LOG}"
    echo "iam_role_arn=$iam_role_arn" 2>&1 | tee -a "${LOG}"
    echo "delete_after_days=$delete_after_days" 2>&1 | tee -a "${LOG}"
    echo "region=$region" 2>&1 | tee -a "${LOG}"
    echo "" 2>&1 | tee -a "${LOG}"

done < ${LIST}

read -p "処理を続行しますか？ (yes/no): " answer
case "$answer" in
    yes|YES|y|Y)
        echo "処理を続行します..."
        ;;
    no|NO|n|N)
        echo "処理を中止します。"
        exit 0
        ;;
    *)
        echo "yes か no を入力してください。"
        exit 1
        ;;
esac

##################################################
# 主処理
##################################################
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${SCRIPT_NAME}.sh の全体処理を開始します。" 2>&1 | tee -a "${LOG}"

#-------------------------------------------------
# バックアップジョブを開始
# 開始ジョブのジョブIDをジョブID格納用配列に格納
#-------------------------------------------------
# ジョブID格納用
job_ids=()
# 開始ジョブ集計用
cnt=0
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] バックアップジョブを開始します。" 2>&1 | tee -a "${LOG}"
while read -r resource backup_vault_name resource_arn iam_role_arn delete_after_days region
do
    # 前後のタブ・空白・改行を削除
    resource="${resource//[$'\t\r\n ']/}"
    backup_vault_name="${backup_vault_name//[$'\t\r\n ']/}"
    resource_arn="${resource_arn//[$'\t\r\n ']/}"
    iam_role_arn="${iam_role_arn//[$'\t\r\n ']/}"
    delete_after_days="${delete_after_days//[$'\t\r\n ']/}"
    region="${region//[$'\t\r\n ']/}"

    # echo "resource=$resource" 2>&1 | tee -a "${LOG}"
    # echo "backup_vault_name=$backup_vault_name" 2>&1 | tee -a "${LOG}" # debug
    # echo "resource_arn=$resource_arn" 2>&1 | tee -a "${LOG}" # debug
    # echo "iam_role_arn=$iam_role_arn" 2>&1 | tee -a "${LOG}" # debug
    # echo "delete_after_days=$delete_after_days" 2>&1 | tee -a "${LOG}" # debug
    # echo "region=$region" 2>&1 | tee -a "${LOG}" # debug

    job_ids[$cnt]=`aws backup start-backup-job \
      --backup-vault-name "$backup_vault_name" \
      --resource-arn "$resource_arn" \
      --iam-role-arn "$iam_role_arn" \
      --lifecycle DeleteAfterDays="$delete_after_days" \
      --region "$region" \
      --output json |grep BackupJobId |awk '{print $2}' |tr -d '",'`
    cnt=`expr $cnt + 1`
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] resource=$resource" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] backup_vault_name=$backup_vault_name" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] resource_arn=$resource_arn" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] iam_role_arn=$iam_role_arn" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] delete_after_days=$delete_after_days" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] region=$region" 2>&1 | tee -a "${LOG}"
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $cnt 件目のジョブが開始されました。" 2>&1 | tee -a "${LOG}"
    echo "" 2>&1 | tee -a "${LOG}"
done < ${LIST}

echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 開始されたジョブID一覧" 2>&1 | tee -a "${LOG}"
for i in "${job_ids[@]}"; do
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $i" 2>&1 | tee -a "${LOG}"
done

# 開始ジョブの合計
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 合計 $cnt 件のジョブが開始されました。" 2>&1 | tee -a "${LOG}"

#-------------------------------------------------
# バックアップジョブ詳細確認コマンドにジョブIDを渡してステータスを確認
# 全ジョブのステータスがRUNNINGからCOMPLETEDに変わるまで監視します。
# 特定時間毎に監視して全ステータスがCOMPLETEDになったら監視を終了します。
#-------------------------------------------------
# 実行中ジョブ監視間隔(秒)集計用
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 全てのジョブが完了するまで待機します。" 2>&1 | tee -a "${LOG}"
cnt_sleep=0
while true
do
    # 実行中ジョブ数の集計用
    cnt_running_status=0
    for i in "${job_ids[@]}"; do
        # 前後のタブ・空白・改行を削除
        i="${i//[$'\t\r\n ']/}"
        status=`aws backup describe-backup-job --backup-job-id "$i" |grep State |awk '{print $2}' |tr -d '",'`
        # 前後のタブ・空白・改行を削除
        status="${status//[$'\t\r\n ']/}"
        if [[ $status = "COMPLETED" ]]; then
            echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ジョブID：$i は $status" 2>&1 | tee -a "${LOG}"
        else
            echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ジョブID：$i は $status" 2>&1 | tee -a "${LOG}"
            cnt_running_status=`expr $cnt_running_status + 1`
        fi
    done
    # 実行中ジョブ集計用カウンターが加算されない場合は全ジョブ完了のためループをブレイク
    if [[ $cnt_running_status -eq 0 ]]; then
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] 全てのジョブが完了しました。" 2>&1 | tee -a "${LOG}"
        break
    fi
    # 待機
    sleep 60
    cnt_sleep=`expr $cnt_sleep + 60`
    minutes=`expr $cnt_sleep / 60`
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ここまでの待ち時間合計：$minutes minutes" 2>&1 | tee -a "${LOG}"
done

#-------------------------------------------------
# バックアップしたリカバリポイント情報を表示
#-------------------------------------------------
# 取得したバックアップのリソースの種類ごとに件数を保持
cnt_ec2=0
cnt_efs=0
cnt_rds=0
backup_vault_name_ec2=""
backup_vault_name_efs=""
backup_vault_name_rds=""
while read -r resource backup_vault_name resource_arn iam_role_arn delete_after_days region
do
    # 前後のタブ・空白・改行を削除
    resource="${resource//[$'\t\r\n ']/}"
    
    if [[ $resource = ec2 ]]; then
        cnt_ec2=`expr $cnt_ec2 + 1`
        backup_vault_name_ec2=$backup_vault_name
    elif [[ $resource = efs ]]; then
        cnt_efs=`expr $cnt_efs + 1`
        backup_vault_name_efs=$backup_vault_name
    else
        cnt_rds=`expr $cnt_rds + 1`
        backup_vault_name_rds=$backup_vault_name
    fi
done < ${LIST}

# echo "cnt_ec2=$cnt_ec2 backup_vault_name_ec2=$backup_vault_name_ec2" # debug
# echo "cnt_efs=$cnt_efs backup_vault_name_efs=$backup_vault_name_efs" # debug
# echo "cnt_rds=$cnt_rds backup_vault_name_rds=$backup_vault_name_rds" # debug

# EC2インスタンスのバックアップ取得している場合、リカバリーポイント表示関数の呼び出し
if [[ $backup_vault_name_ec2 != "" ]]; then
    func_show_recovery_point $cnt_ec2 $backup_vault_name_ec2
fi

# EFSのバックアップ取得している場合、リカバリーポイント表示関数の呼び出し
if [[ $backup_vault_name_efs != "" ]]; then
    func_show_recovery_point $cnt_efs $backup_vault_name_efs
fi

# RDSのバックアップ取得している場合、リカバリーポイント表示関数の呼び出し
if [[ $backup_vault_name_rds != "" ]]; then
    func_show_recovery_point $cnt_rds $backup_vault_name_rds
fi

##################################################
# 後処理
##################################################
# 正常終了
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${SCRIPT_NAME}.sh の全体処理が成功しました。" 2>&1 | tee -a "${LOG}"
exit 0
