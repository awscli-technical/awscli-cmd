#!/bin/bash
####################################################################################################
#    プログラム名  :  OS上で各種リソース状況取得するコマンドを発行
#    ファイル名    :  get_resource_info.sh
#    作成者        :  
#    作成日        :  2025/04/01
#    備考          :  
#    変更履歴      :
#
#    日付        更新者    内容
#    2025/04/01  xxxxx     新規作成
#
#    引数          :  $1(例 get resource info.conf)
#    戻り値        :  0(正常)
#                  :  1(異常)
#    使用例        :
#                     任意のディレクトリにスクリプトを配置します。
#                     tree --charset=ASCII ./
#                     ./
#                     |-- conf
#                     |   |-- common.conf
#                     |   `-- get_resource_info.conf
#                     |-- get_resource_info.sh
#                     `-- log
#                         `-- get_resource_info_20250419-094557.log
#                    
#                     実行権限を付与します。
#                     chmod u+x get_resource_info.sh
#                    
#                     完了したら動作確認を実施します。
#                     $ bash get_resource_info.sh get_resource_info.conf
#                    
#                     OS機能で自動実行させる場合はcronに登録します。
#                     crontab -e
#                     */10 * * * * /usr/bin/bash -c "/var/lib/pgsql/work/git/sh/bash/os/rhel/general/get_resource_info.sh get_resource_info.conf" >/dev/null 2>&1
#                    
#                     cronに登録した内容を確認します。
#                     crontab -l
#                     */10 * * * * /usr/bin/bash -c "/var/lib/pgsql/work/git/sh/bash/os/rhel/general/get_resource_info.sh get_resource_info.conf" >/dev/null 2>&1
#
#                     cron関連)
#                     /var/spool/cron/root
#                     /var/log/cron
#                     systemctl status crond
#
####################################################################################################
##################################################
# 関数定義
##################################################
#-------------------------------------------------
# 関数名  :  エラーハンドリング
# 機能    :  実行結果の戻り値と正常系・異常系メッセージを受取ります。
#            実行結果の戻り値が0の場合は正常系メッセージを表示します。
#            実行結果の戻り値が0以外の場合は異常系メッセージを表示します。
# 引数    :  $1(コマンドの戻り値)
#            $2(正常系メッセージ)
#            $3(異常系メッセージ)
#-------------------------------------------------
function proc_err_handling() {
    if [[ "$1" -eq 0 ]]; then
        # 正常系メッセージをコンソールとログファイルに出力して戻り値0を返す
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $2" 2>&1 | tee -a "${LOG}"
        echo "${MSG_SEPARATOER}" 2>&1 | tee -a "${LOG}"
        return 0
    else
        # システムログにエラーを通知
        logger -i -p user.err "[${HOST_NAME}] Monitoring notification code [${SCRIPT_NAME}.sh] Error code [$3]"
        # 異常系メッセージをコンソールとログファイルに出力して戻り値1を返す
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $3" 2>&1 | tee -a "${LOG}"
        echo "${MSG_SEPARATOER}" 2>&1 | tee -a "${LOG}"
        return 1
    fi
}

#-------------------------------------------------
# 関数名  :  各種コマンド発行
# 機能    :  各種OSコマンドを発行します。
# 引数    :  $1(コマンド概要説明)
#            $2(OSコマンド)
#-------------------------------------------------
function proc_general_query() {
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_GENERAL_QUERY}" 2>&1 | tee -a "${LOG}"
    # コマンド概要説明
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $1" 2>&1 | tee -a "${LOG}"
    # コマンド表示
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $2" 2>&1 | tee -a "${LOG}"
    # コマンド実行
    set -f # ワイルドカード無効化
    bash -c "$2" 2>&1 | tee -a "${LOG}"
    CMD_RC=${PIPESTATUS[0]}
    set +f # ワイルドカード無効化解除
    # エラーハンドリング関数呼出
    proc_err_handling "${CMD_RC}" "${MSG_SUCCESS_GENERAL_QUERY}" "${MSG_FAILURE_GENERAL_QUERY}"
}

##################################################
# 前処理
##################################################
#-------------------------------------------------
# 共通パラメータ取得
#-------------------------------------------------
#COMMON_CONF="/var/lib/pgsql/work/git/sh/bash/postgres/analyze/conf/common.conf"
COMMON_CONF="/var/lib/pgsql/work/git/sh/bash/os/rhel/general/conf/common.conf"
. "${COMMON_CONF}"

#-------------------------------------------------
# 特定パラメータ取得
#-------------------------------------------------
#DATABASE_CONNECT_CONF="/var/lib/pgsql/work/git/sh/bash/postgres/analyze/conf/$1"
DATABASE_CONNECT_CONF="/var/lib/pgsql/work/git/sh/bash/os/rhel/general/conf/$1"
. "${DATABASE_CONNECT_CONF}"

##-----------------------------------------------
## 共通パラメータ取得確認(デバック用途)
##-----------------------------------------------
param=(
    DATE="${DATE}"
    SCRIPT_NAME="${SCRIPT_NAME}"
    LOG_DATE="${LOG_DATE}"
    LOG_PATH="${LOG_PATH}"
    LOG="${LOG}"
    DIR_NUM="${DIR_NUM}"
    FILE_NUM="${FILE_NUM}"
    FILE_SIZE="${FILE_SIZE}"
    LOG_DELETE="${LOG_DELETE}"
    HOST_NAME="${HOST_NAME}"
    EXECUTE_USER="${EXECUTE_USER}"
    MSG_START_GENERAL_QUERY="${MSG_START_GENERAL_QUERY}"
    MSG_SUCCESS_GENERAL_QUERY="${MSG_SUCCESS_GENERAL_QUERY}"
    MSG_FAILURE_GENERAL_QUERY="${MSG_FAILURE_GENERAL_QUERY}"
    MSG_SEPARATOER="${MSG_SEPARATOER}"
    MSG_MAKE_LOG_DIRECTORY="${MSG_MAKE_LOG_DIRECTORY}"
    MSG_EXECUTE_USER_NOT_EXIST="${MSG_EXECUTE_USER_NOT_EXIST}"
    MSG_SUCCESS_LOG_DELETE="${MSG_SUCCESS_LOG_DELETE}"
    MSG_FAILURE_LOG_DELETE="${MSG_FAILURE_LOG_DELETE}"
    MSG_START_THIS="${MSG_START_THIS}"
    MSG_SUCCESS_END_THIS="${MSG_SUCCESS_END_THIS}"
    MSG_FAILURE_END_THIS="${MSG_FAILURE_END_THIS}"
    `echo "--"`
    COM_DESC_SYS_CPU="${COM_DESC_SYS_CPU}"
    COM_SYS_CPU="${COM_SYS_CPU}"
    `echo "--"`
    COM_DESC_SYS_MEMORY="${COM_DESC_SYS_MEMORY}"
    COM_SYS_MEMORY="${COM_SYS_MEMORY}"
    `echo "--"`
    COM_DESC_SYS_STORAGE="${COM_DESC_SYS_STORAGE}"
    COM_SYS_STORAGE="${COM_SYS_STORAGE}"
    `echo "--"`
    COM_DESC_SYS_OS_VER="${COM_DESC_SYS_OS_VER}"
    COM_SYS_OS_VER="${COM_SYS_OS_VER}"
    `echo "--"`
    COM_DESC_SYS_HOST_NAME="${COM_DESC_SYS_HOST_NAME}"
    COM_SYS_HOST_NAME="${COM_SYS_HOST_NAME}"
    `echo "--"`
    COM_DESC_SYS_LOCALE="${COM_DESC_SYS_LOCALE}"
    COM_SYS_LOCALE="${COM_SYS_LOCALE}"
    `echo "--"`
    COM_DESC_SYS_UPTIME="${COM_DESC_SYS_UPTIME}"
    COM_SYS_UPTIME="${COM_SYS_UPTIME}"
    `echo "--"`
    COM_DESC_SYS_SWAP="${COM_DESC_SYS_SWAP}"
    COM_SYS_SWAP="${COM_SYS_SWAP}"
    `echo "--"`
    COM_DESC_SYS_MEMORY_FREE="${COM_DESC_SYS_MEMORY_FREE}"
    COM_SYS_MEMORY_FREE="${COM_SYS_MEMORY_FREE}"
    `echo "--"`
    COM_DESC_DISK_DF="${COM_DESC_DISK_DF}"
    COM_DISK_DF="${COM_DISK_DF}"
    `echo "--"`
    COM_DESC_DISK_DF_I="${COM_DESC_DISK_DF_I}"
    COM_DISK_DF_I="${COM_DISK_DF_I}"
    `echo "--"`
    COM_DESC_DISK_DU="${COM_DESC_DISK_DU}"
    COM_DISK_DU="${COM_DISK_DU}"
    `echo "--"`
    COM_DESC_DISK_LARGE_DIR="${COM_DESC_DISK_LARGE_DIR}"
    COM_DISK_LARGE_DIR="${COM_DISK_LARGE_DIR}"
    `echo "--"`
    COM_DESC_DISK_LARGE_FILE="${COM_DESC_DISK_LARGE_FILE}"
    COM_DISK_LARGE_FILE="${COM_DISK_LARGE_FILE}"
    `echo "--"`
    COM_DESC_DISK_LARGE_FILE_X="${COM_DESC_DISK_LARGE_FILE_X}"
    COM_DISK_LARGE_FILE_X="${COM_DISK_LARGE_FILE_X}"
    `echo "--"`
    COM_DESC_SYS_PS_AUX="${COM_DESC_SYS_PS_AUX}"
    COM_SYS_PS_AUX="${COM_SYS_PS_AUX}"
    `echo "--"`
    COM_DESC_SYS_PS_EF="${COM_DESC_SYS_PS_EF}"
    COM_SYS_PS_EF="${COM_SYS_PS_EF}"
    `echo "--"`
    COM_DESC_SYS_PSTREE="${COM_DESC_SYS_PSTREE}"
    COM_SYS_PSTREE="${COM_SYS_PSTREE}"
    `echo "--"`
    COM_DESC_DISK_LARGE_DIR_OF_PROC="${COM_DESC_DISK_LARGE_DIR_OF_PROC}"
    `echo "--"`
    COM_DESC_DISK_LARGE_FILE_OF_PROC="${COM_DESC_DISK_LARGE_FILE_OF_PROC}"
)

for i in "${param[@]}"; do
    echo $i 2>&1 | tee -a "${LOG}"
done

#-------------------------------------------------
# ログ格納ディレクトリ存在確認
#-------------------------------------------------
if [[ ! -d log ]]; then
    # ログ格納ディレクトリが存在しない場合は作成
    mkdir log
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_MAKE_LOG_DIRECTORY}" 2>&1 | tee -a "${LOG}"
fi

#-------------------------------------------------
# 実行ユーザ存在確認
#-------------------------------------------------
WHOAMI=""
WHOAMI=$(cat /etc/passwd | grep ^${EXECUTE_USER} | awk -F : '{print $1}')
if [[ ! "${WHOAMI}" ]]; then
    # 実行ユーザが存在しない場合は異常終了
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_EXECUTE_USER_NOT_EXIST}" 2>&1 | tee -a "${LOG}"
    exit 1
fi

# 全体処理開始
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_THIS}" 2>&1 | tee -a "${LOG}"

##################################################
# 主処理
##################################################
# 各種コマンドの実行
while read QUERY_DESC QUERY;do
  proc_general_query "${QUERY_DESC}" "${QUERY}"
  FUNC_RC="$?"
  if [[ "${FUNC_RC}" != 0 ]]; then
      echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_FAILURE_END_THIS}" 2>&1 | tee -a "${LOG}"
      # 異常終了
      exit 1
  fi
done << EOL
${COM_DESC_SYS_CPU} ${COM_SYS_CPU}
${COM_DESC_SYS_MEMORY} ${COM_SYS_MEMORY}
${COM_DESC_SYS_STORAGE} ${COM_SYS_STORAGE}
${COM_DESC_SYS_OS_VER} ${COM_SYS_OS_VER}
${COM_DESC_SYS_HOST_NAME} ${COM_SYS_HOST_NAME}
${COM_DESC_SYS_UPTIME} ${COM_SYS_UPTIME}
${COM_DESC_SYS_SWAP} ${COM_SYS_SWAP}
${COM_DESC_SYS_MEMORY_FREE} ${COM_SYS_MEMORY_FREE}
${COM_DESC_DISK_DF} ${COM_DISK_DF}
${COM_DESC_DISK_DF_I} ${COM_DISK_DF_I}
${COM_DESC_DISK_DU} ${COM_DISK_DU}
${COM_DESC_DISK_LARGE_DIR} ${COM_DISK_LARGE_DIR}
${COM_DESC_DISK_LARGE_FILE} ${COM_DISK_LARGE_FILE}
${COM_DESC_DISK_LARGE_FILE_X} ${COM_DISK_LARGE_FILE_X}
${COM_DESC_SYS_PS_AUX} ${COM_SYS_PS_AUX}
${COM_DESC_SYS_PS_EF} ${COM_SYS_PS_EF}
${COM_DESC_SYS_PSTREE} ${COM_SYS_PSTREE}
EOL

# ルートディレクトリ(/)配下の特定数のディレクトリとそのディレクトリを使用しいているプロセスを降順表示
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_GENERAL_QUERY}" 2>&1 | tee -a "${LOG}"
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${COM_DESC_DISK_LARGE_DIR_OF_PROC}" 2>&1 | tee -a "${LOG}"
for i in `du -a / --exclude=/proc |sort -rn |head -n 10 |awk '{print $2}'`
do
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] fuser -vm $i"  2>&1 | tee -a "${LOG}"
    fuser -vm $i  2>&1 | tee -a "${LOG}"
    echo "----" 2>&1 | tee -a "${LOG}"
done
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_SUCCESS_GENERAL_QUERY}" 2>&1 | tee -a "${LOG}"
echo "${MSG_SEPARATOER}" 2>&1 | tee -a "${LOG}"

# ルートディレクトリ(/)配下の特定数のファイルとそのファイルを使用しいているプロセスを降順表示
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_GENERAL_QUERY}" 2>&1 | tee -a "${LOG}"
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${COM_DESC_DISK_LARGE_FILE_OF_PROC}" 2>&1 | tee -a "${LOG}"
for i in `find / -path /proc -prune -o -type f -exec du -h {} + | sort -rh | head -n 20 |awk '{print $2}'`
do
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] fuser -v $i" 2>&1 | tee -a "${LOG}"
    fuser -v $i  2>&1 | tee -a "${LOG}"
    echo "----" 2>&1 | tee -a "${LOG}"
done
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_SUCCESS_GENERAL_QUERY}" 2>&1 | tee -a "${LOG}"
echo "${MSG_SEPARATOER}" 2>&1 | tee -a "${LOG}"

##################################################
# 後処理
##################################################
#-------------------------------------------------
# 特定日数を経過したログの削除
#-------------------------------------------------
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${LOG_DELETE} 日以上経過したログの削除を開始します。" 2>&1 | tee -a "${LOG}"
find ${LOG_PATH} -mtime +${LOG_DELETE} -name *.log | xargs rm -f
CMD_RC=$(echo $?)
# エラーハンドリング関数呼出
proc_err_handling "${CMD_RC}" "${MSG_SUCCESS_LOG_DELETE}" "${MSG_FAILURE_LOG_DELETE}"

# 全体処理正常終了
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_SUCCESS_END_THIS}" 2>&1 | tee -a "${LOG}"
# aws sns publish --topic-arn "${SNS_TOPIC_ARN}" --subject "${SNS_SUB_SUCCESS}" --message "${MSG_SUCCESS_END_THIS}" 2>&1 | tee -a "${LOG}"

exit 0
