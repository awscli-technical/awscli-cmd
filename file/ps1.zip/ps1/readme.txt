■動作確認環境
■前提条件
■実行方法


■動作確認環境

  ▼OS
  Windows
  
  ▼スクリプト
  branch_auto.ps1
  rc0_dummy00.ps1
  rc0_dummy01.ps1
  rc1_dummy00.ps1
  rc1_dummy01.ps1
  rc1_dummy02.ps1
  remake_fileWait.ps1
  start_rc0.ps1
  start_rc1.ps1
  
  ▼スクリプトログ
  branch_auto.log
  rc0_dummy00.log
  rc0_dummy01.log
  rc1_dummy00.log
  rc1_dummy01.log
  rc1_dummy02.log
  start_rc0.log
  start_rc1.log
  
  ▼配置ディレクトリ
  任意のディレクトリ


■前提条件

  ▼スクリプトファイル(拡張子.ps1)のフォーマット
  ・UTF-8のBOM形式で保存されていること


■実行方法

①Powershellを起動します。
②ps1配置場所に移動します。
  例）cd C:\work\local\script_wk\テスト済スクリプト\mdis_SWOM_ジョブスキップ\tmp
③実行ポリシーを変更します。
  > Set-ExecutionPolicy Bypass -Scope Process
  > PowerShell Get-ExecutionPolicy
  Bypass
④実行します。
  例）./remake_fileWait.ps1
