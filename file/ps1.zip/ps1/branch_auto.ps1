﻿# PowerShellスクリプト

# 引数を受け取ります
$RC = Get-Content csv/fileWait

# ログファイルの設定
$SCRIPT_NAME = [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)
$LOG_PATH = "log"
$LOG = "$LOG_PATH\$SCRIPT_NAME.log"

# ログディレクトリが存在しない場合は作成
if (!(Test-Path $LOG_PATH)) {
    New-Item -ItemType Directory -Path $LOG_PATH | Out-Null
}

# ログ出力
$timestamp = Get-Date -Format "yyyy/MM/dd HH:mm:ss"
$hostname = $env:COMPUTERNAME

Write-Output "日付:$timestamp" | Tee-Object -FilePath $LOG
Write-Output "ホスト名:$hostname" | Tee-Object -Append -FilePath $LOG
Write-Output "数値を受取り、その数値を返します。" | Tee-Object -Append -FilePath $LOG
Write-Output "受取値:$RC" | Tee-Object -Append -FilePath $LOG
Write-Output "返却値:$RC" | Tee-Object -Append -FilePath $LOG

exit [int]$RC
