﻿# PowerShellスクリプト

# ディレクトリ "csv" を作成（存在しない場合）
if (!(Test-Path "csv")) {
    New-Item -ItemType Directory -Path "csv" | Out-Null
}

# 既存ファイル削除
Remove-Item -Path "csv\*" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

Remove-Item -Path "log\*" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

# ファイル作成
@"
0
"@ | Set-Content -Path "csv\fileWait"