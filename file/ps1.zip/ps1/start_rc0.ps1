﻿# PowerShellスクリプト

# ログファイルの設定
$SCRIPT_NAME = [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)
$LOG_PATH = "log"
$LOG = "$LOG_PATH\$SCRIPT_NAME.log"

# ログディレクトリが存在しない場合は作成
if (!(Test-Path $LOG_PATH)) {
    New-Item -ItemType Directory -Path $LOG_PATH | Out-Null
}

# ログ出力
$timestamp = Get-Date -Format "yyyy/MM/dd HH:mm:ss"
$hostname = $env:COMPUTERNAME

Write-Output "日付:$timestamp" | Tee-Object -FilePath $LOG
Write-Output "ホスト名:$hostname" | Tee-Object -Append -FilePath $LOG
Write-Output "前ジョブ返却値0の場合の開始ジョブです。" | Tee-Object -Append -FilePath $LOG

exit 0