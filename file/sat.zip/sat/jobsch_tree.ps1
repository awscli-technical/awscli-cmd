#
# グループ配下のジョブネットを再帰的に表示する (PowerShell版)
#
# 使い方:
#   .\jobsch_tree.ps1 -Group "プロジェクト名/グループ名"
#
# 例:
#   .\jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#
# --- Windows上での実行方法 ---
#
# 1. 実行ポリシーの確認・変更 (初回のみ)
#    PowerShellを管理者として開き、以下を実行:
#      Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
#
# 2. スクリプトの実行
#    PowerShellを開き、スクリプトのあるディレクトリに移動して実行:
#      cd C:\path\to\script
#      .\jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#
# 3. jobschprintコマンドにパスが通っていない場合
#    事前に環境変数PATHにjobschprintのディレクトリを追加するか、
#    スクリプト内のjobschprintをフルパスに書き換えてください。
#
# 4. 文字化けする場合
#    PowerShellで以下を実行してからスクリプトを実行:
#      [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
#      $env:LANG = "ja_JP.UTF-8"
#
# --- Linux上での実行方法 ---
#
#   pwsh ./jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#

param(
    [Parameter(Mandatory=$true)]
    [string]$Group
)

$script:Project = ($Group -split '/')[0]

function Print-JobNets {
    param(
        [string]$NetName,
        [string]$Indent = ""
    )

    Write-Output "${Indent}${NetName}"

    # ジョブネットの詳細を取得
    $detail = jobschprint -r "$($script:Project)/${NetName}" -detail 2>$null

    # JOBブロックを解析してサブジョブネット(JNET)を抽出
    $inJob = $false
    $jobName = ""
    $isJnet = $false

    foreach ($line in $detail) {
        $trimmed = $line.Trim()

        if ($trimmed -eq "JOB") {
            $inJob = $true
            $jobName = ""
            $isJnet = $false
        }
        elseif ($inJob -and $trimmed -match "^jobname\s+(.+)$") {
            $jobName = $Matches[1]
        }
        elseif ($inJob -and $trimmed -eq "jobicon JNET") {
            $isJnet = $true
        }
        elseif ($inJob -and $trimmed -eq ";") {
            if ($isJnet -and $jobName -ne "") {
                Print-JobNets -NetName $jobName -Indent "  ${Indent}"
            }
            $inJob = $false
        }
    }
}

# グループ配下のジョブネット一覧を取得
$groupOutput = jobschprint -R $Group 2>$null
$jobnets = $groupOutput | Where-Object { $_ -match "^\s*jobnetname\s+" } | ForEach-Object {
    ($_ -replace "^\s*jobnetname\s+", "").Trim()
}

foreach ($net in $jobnets) {
    Print-JobNets -NetName $net
}
