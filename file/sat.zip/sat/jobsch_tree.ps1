#
# グループ配下のジョブネットを再帰的に表示する (PowerShell版)
#
# 使い方:
#   .\jobsch_tree.ps1 -Group "プロジェクト名/グループ名"
#
# 例:
#   .\jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#
# --- Windows上での実行方法 ---
#
# 1. 実行ポリシーの確認・変更 (初回のみ)
#    PowerShellを管理者として開き、以下を実行:
#      Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
#
# 2. スクリプトの実行
#    PowerShellを開き、スクリプトのあるディレクトリに移動して実行:
#      cd C:\path\to\script
#      .\jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#
# 3. jobschprintコマンドにパスが通っていない場合
#    事前に環境変数PATHにjobschprintのディレクトリを追加するか、
#    スクリプト内の$JobSchCmd変数をフルパスに書き換えてください。
#    例: $JobSchCmd = "C:\Program Files\JobScheduler\bin\jobschprint.exe"
#
# 4. 文字化けする場合
#    PowerShellで以下を実行してからスクリプトを実行:
#      [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
#      chcp 65001
#
# --- Linux上での実行方法 ---
#
#   pwsh ./jobsch_tree.ps1 -Group "PRJ-GRP-ORG/group10"
#

param(
    [Parameter(Mandatory=$true)]
    [string]$Group
)

# コマンドパス (環境に合わせて変更可能)
$script:JobSchCmd = "jobschprint"

$script:Project = ($Group -split '/')[0]

function Print-JobNets {
    param(
        [string]$NetName,
        [string]$Indent = ""
    )

    Write-Output "${Indent}${NetName}"

    # ジョブネットの詳細を取得
    $ErrorActionPreference = "SilentlyContinue"
    $detail = & $script:JobSchCmd -r "$($script:Project)/${NetName}" -detail 2>&1 |
        Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] } |
        ForEach-Object { $_.ToString() }
    $ErrorActionPreference = "Continue"

    if ($null -eq $detail) { return }

    # JOBブロックを解析してサブジョブネット(JNET)を抽出
    $inJob = $false
    $jobName = ""
    $isJnet = $false

    foreach ($line in $detail) {
        $trimmed = $line.Trim()

        if ($trimmed -eq "JOB") {
            $inJob = $true
            $jobName = ""
            $isJnet = $false
        }
        elseif ($inJob -and ($trimmed -match "^jobname\s+(.+)$")) {
            $jobName = $Matches[1]
        }
        elseif ($inJob -and ($trimmed -eq "jobicon JNET")) {
            $isJnet = $true
        }
        elseif ($inJob -and ($trimmed -eq ";")) {
            if ($isJnet -and ($jobName -ne "")) {
                Print-JobNets -NetName $jobName -Indent "  ${Indent}"
            }
            $inJob = $false
        }
    }
}

# グループ配下のジョブネット一覧を取得
$ErrorActionPreference = "SilentlyContinue"
$groupOutput = & $script:JobSchCmd -R $Group 2>&1 |
    Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] } |
    ForEach-Object { $_.ToString() }
$ErrorActionPreference = "Continue"

if ($null -eq $groupOutput) {
    Write-Error "グループ '${Group}' の情報を取得できませんでした"
    exit 1
}

$jobnets = $groupOutput | Where-Object { $_ -match "^\s*jobnetname\s+" } | ForEach-Object {
    ($_ -replace "^\s*jobnetname\s+", "").Trim()
}

foreach ($net in $jobnets) {
    Print-JobNets -NetName $net
}
