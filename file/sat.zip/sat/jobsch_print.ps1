#
# jobschprintcsv を指定期間・指定ジョブネットで一括実行するスクリプト (PowerShell版)
#
# 使い方:
#   .\jobsch_print.ps1 -StartYear 2026 -StartMonth 06 -EndYear 2027 -EndMonth 03 -JobNet "jobnet00"
#
# --- Windows上での実行方法 ---
#
# 1. 実行ポリシーの確認・変更 (初回のみ)
#    PowerShellを管理者として開き、以下を実行:
#      Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
#
# 2. スクリプトの実行
#    PowerShellを開き、スクリプトのあるディレクトリに移動して実行:
#      cd C:\path\to\script
#      .\jobsch_print.ps1 -StartYear 2026 -StartMonth 06 -EndYear 2027 -EndMonth 03 -JobNet "jobnet00"
#
# 3. jobschprintcsvコマンドにパスが通っていない場合
#    事前に環境変数PATHにjobschprintcsvのディレクトリを追加するか、
#    スクリプト内のjobschprintcsvをフルパスに書き換えてください。
#
# 4. 文字化けする場合
#    PowerShellで以下を実行してからスクリプトを実行:
#      [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
#      $env:LANG = "ja_JP.UTF-8"
#
# --- Linux上での実行方法 ---
#
#   pwsh ./jobsch_print.ps1 -StartYear 2026 -StartMonth 06 -EndYear 2027 -EndMonth 03 -JobNet "jobnet00"
#

param(
    [Parameter(Mandatory=$true)]
    [int]$StartYear,

    [Parameter(Mandatory=$true)]
    [int]$StartMonth,

    [Parameter(Mandatory=$true)]
    [int]$EndYear,

    [Parameter(Mandatory=$true)]
    [int]$EndMonth,

    [Parameter(Mandatory=$true)]
    [string]$JobNet
)

# --- 実行 ---
$year = $StartYear
$month = $StartMonth
$first = $true

while ($true) {
    # 終了年月を超えたらループ終了
    if ($year -gt $EndYear) { break }
    if ($year -eq $EndYear -and $month -gt $EndMonth) { break }

    # 月を2桁ゼロ埋め
    $mm = "{0:D2}" -f $month

    $output = jobschprintcsv -l "$year" "$mm" -title 2>$null

    if ($first) {
        # 最初の月はヘッダー行も出力
        $output | Where-Object { $_ -match "^Host Name" -or $_ -match $JobNet }
        $first = $false
    }
    else {
        $output | Where-Object { $_ -match $JobNet }
    }

    # 次の月へ
    $month++
    if ($month -gt 12) {
        $month = 1
        $year++
    }
}
