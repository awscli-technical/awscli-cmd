## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json --timeout 900
## lambda-uploader
## ResourceGroupsandTagEditorReadOnlyAccess(IAM policy) is required
import boto3
import os

resourcegroupstaggingapi_client = boto3.client('resourcegroupstaggingapi')
workspaces_client = boto3.client('workspaces')

def lambda_handler(event, context):
    ## 環境変数の読み込みます。
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)

    ## タグフィルタリング設定します。
    tag_filters = [
        {
            'Key': target_tag_key,
            'Values': [target_tag_value]
        }
    ]

    ## タグフィルタリングされたWorkspacesリソース情報の取得します。
    response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters,ResourcesPerPage=1,ResourceTypeFilters = ['workspaces'])
    ## WorkspacesのARNとタグ取得します。
    workspace_list = response["ResourceTagMappingList"]
    ## WorkspaceIdを抽出（辞書型）します。
#    for workspace in workspace_list:
#        workspace_id_tmp1 = workspace["ResourceARN"].split("/")[-1]
#        print("AAAAAAAAAAAAAA")
#        print(workspace_id_tmp1)

#    print("Workspacesを再起動します。")
#    print(workspace_list) ## Debug code

    ## 対象WorkSpacesのステータスチェック
#    rc = describe_workspace(workspace_id_tmp1)
    # if rc == 0:
    #    print('WorkSpace "{0}" status is normal.'.format(workspace_id))
    # else:

    ## ----------------------------------------------------------------------------------
    ## リソースがページ当たりの上限値を超過した場合は次ページ処理を行います。
    ## PaginationToken値が空(対象の全WorkSpaces読込済)になるまで処理を繰り返します。
    ## PaginationToken有:True
    ## PaginationToken無:false
    ## ページ当たりのリソースの上限値は50(デフォルト)で、最大100まで設定可能です。
    ## ResourcesPerPage:上限値
    ## ----------------------------------------------------------------------------------
    while 'PaginationToken' in response and response['PaginationToken']:
        ## PaginationToken値の取得します。
        token = response['PaginationToken']
        response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters, ResourcesPerPage=1, ResourceTypeFilters = ['workspaces'], PaginationToken=token)
        ## WorkspacesのARNとタグ取得します。
        workspace_lists = response["ResourceTagMappingList"]
        ## WorkspaceIdを抽出（辞書型）します。
        # workspace_id = [{"WorkspaceId": workspace["ResourceARN"].split("/")[-1]} for workspace in workspace_lists]
        for workspace in workspace_list:
            workspace_id = workspace["ResourceARN"].split("/")[-1]
            print("BBBBBBBBB")
            print(workspace_id)

        ## WorkspaceIdが空の場合はループを抜けます。
        if str(workspace_id) == '[]':
            break
        print("Pagination後のWorkspacesを再起動します。")
        print(workspace_lists) ## Debug code
        print(workspace_id)

        ## 対象WorkSpacesのステータスチェック
        # rc = describe_workspace(workspace_id)
        rc = describe_workspace(workspace_id)
        # if rc == 0:
        #    print('WorkSpace "{0}" status is normal.'.format(workspace_id))
        # else:
        #    print('WorkSpace "{0}" status is abnormal.'.format(workspace_id))

    return 0

## ----------------------------------------------------------------------------------
## 対象WorkSpacesのステータスチェック用関数
## ----------------------------------------------------------------------------------
def describe_workspace(workspace_id):
    print(">>>>>>>>>>>>>>>")
    print(workspace_id)
    res = workspaces_client.describe_workspaces(WorkspaceIds=[workspace_id])
    #print(res)
    res2 = res['Workspaces']
    print(res2)
    for ws in res2:
        state = ws['State']
        print("State: " + state)
    # execution_result = workspaces_client.describe_workspace(WorkspaceIds=[workspace_id,],)
    # workspaces_client.describe_workspace()

    # user_naem = execution_result['UserName']
    # print(">>>>>>>>>>>>>")
    # print(user_naem)


    # failed_requests = execution_result.get('FailedRequests')
    # if not failed_requests:
    #     return 0
    # else:
    #     print('[Error] {0}'.format(failed_requests))
    #     return 1
