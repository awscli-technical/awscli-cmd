## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json --timeout 900
## lambda-uploader
## ResourceGroupsandTagEditorReadOnlyAccess(IAM policy) is required
import boto3
import os

resourcegroupstaggingapi_client = boto3.client('resourcegroupstaggingapi')
workspaces_client = boto3.client('workspaces')

def lambda_handler(event, context):
    ## 環境変数の読み込みます。
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)

    ## タグフィルタリング設定します。
    tag_filters = [
        {
            'Key': target_tag_key,
            'Values': [target_tag_value]
        }
    ]

    ## タグフィルタリングされたWorkspacesリソース情報の取得します。
    response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters,ResourcesPerPage=1,ResourceTypeFilters = ['workspaces'])
    ## WorkspacesのARNとタグ取得します。(PaginationToken値をここで取得します。次ページ取得時に必要になります。)
    workspace_list = response["ResourceTagMappingList"]
    print("Workspacesを再起動します。")
    # print(workspace_list) ## Debug code
    # print(workspace_id)

    ## WorkspaceIdを抽出します。
    for workspace in workspace_list:
        workspace_id = workspace["ResourceARN"].split("/")[-1]
        print("AAAA")
        print("workspace_id: " + workspace_id)

    status = describe_workspace(workspace_id)
    print(status)

    ## ----------------------------------------------------------------------------------
    ## リソースがページ当たりの上限値を超過した場合は次ページ処理を行います。
    ## PaginationToken値が空(対象の全WorkSpaces読込済)になるまで処理を繰り返します。
    ## PaginationToken有:True
    ## PaginationToken無:false
    ## ページ当たりのリソースの上限値は50(デフォルト)で、最大100まで設定可能です。
    ## ResourcesPerPage:上限値
    ## ----------------------------------------------------------------------------------
    while 'PaginationToken' in response and response['PaginationToken']:
        ## PaginationToken値の取得します。
        token = response['PaginationToken']
        response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters, ResourcesPerPage=1, ResourceTypeFilters = ['workspaces'], PaginationToken=token)
        ## WorkspacesのARNとタグ取得します。
        workspace_lists = response["ResourceTagMappingList"]
        ## WorkspaceIdが空の場合はループを抜けます。
        print("DDDDDDDDDDDDDDDDD: " + workspace_id)
        if str(workspace_id) == '':
            break
        print("Pagination後のWorkspacesを再起動します。")
        # print(workspace_lists) ## Debug code
        # print(workspace_id)

        ## WorkspaceIdを抽出します。
        for workspace in workspace_lists:
            workspace_id = workspace["ResourceARN"].split("/")[-1]
            print("BBBB")
            print("workspace_id: " + workspace_id)

        status = describe_workspace(workspace_id)
        print(status)
        # if rc == 0:
        #    print('WorkSpace "{0}" status is normal.'.format(workspace_id))
        # else:
        #    print('WorkSpace "{0}" status is abnormal.'.format(workspace_id))

    return 0

## ----------------------------------------------------------------------------------
## 対象WorkSpacesのステータスチェック用関数
## ----------------------------------------------------------------------------------
def describe_workspace(workspace_id):
    results = workspaces_client.describe_workspaces(WorkspaceIds=[workspace_id])
    print("CCCC")
    print("workspace_id: " + workspace_id)
    result = results['Workspaces']
    # print(result)
    for workspace in result:
        directory_id = workspace['DirectoryId']
        user_name = workspace['UserName']
        state = workspace['State']
        computer_name = workspace['ComputerName']

    return f"DirectoryId:{directory_id}, WorkspaceId:{workspace_id}, UserName:{user_name}, State:{state}, ComputerName:{computer_name}"
