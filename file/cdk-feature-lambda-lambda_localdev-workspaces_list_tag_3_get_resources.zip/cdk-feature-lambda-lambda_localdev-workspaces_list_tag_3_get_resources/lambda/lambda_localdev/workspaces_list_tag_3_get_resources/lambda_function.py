## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json --timeout 900
## lambda-uploader
## ResourceGroupsandTagEditorReadOnlyAccess(IAM policy) is required
import boto3
import os

resourcegroupstaggingapi_client = boto3.client('resourcegroupstaggingapi')
workspaces_client = boto3.client('workspaces')
sns = boto3.client('sns')

def lambda_handler(event, context):
    ## 環境変数の読み込み
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    sns_topic_arn       = os.environ.get('SNS_TOPIC_ARN', '')
    alarm_subject       = os.environ.get('ALARM_SUBJECT', '')
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)
    print("SNS_TOPIC_ARN = " + sns_topic_arn)
    print("ALARM_SUBJECT = " + alarm_subject)

    ## タグフィルタリングの設定
    tag_filters = [
        {
            'Key': target_tag_key,
            'Values': [target_tag_value]
        }
    ]

    ## 特定タグ付きのWorkspaces情報を取得
    response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters,ResourcesPerPage=1,ResourceTypeFilters = ['workspaces'])
    ## WorkspacesのARNとタグ情報を取得
    workspace_list = response["ResourceTagMappingList"]
    ## WorkspaceIdの抽出（辞書型）
    workspace_id = [{"WorkspaceId": workspace["ResourceARN"].split("/")[-1]} for workspace in workspace_list]

    print("特定タグ付きWorkspacesの状態を確認します。")
    ## WorkspacesのARNとタグ情報を表示
    print(workspace_list)

    ## WorkspaceIdの抽出
    for workspace in workspace_list:
        workspace_id = workspace["ResourceARN"].split("/")[-1]

    ## 対象WorkSpacesの状態確認（WorkSpacesの状態確認用関数呼び出し）
    status = describe_workspace(workspace_id)
    ## 関数戻り値の表示
    print(status)
    ## 関数戻り値を格納する配列
    status_list = []
    ## 関数戻り値を配列に格納
    status_list.append(status)

    ## ----------------------------------------------------------------------------------
    ## リソースがページ当たりの上限値を超過した場合は次ページ処理を行います。
    ## PaginationToken値が空(対象の全WorkSpaces読込済)になるまで処理を繰り返します。
    ## PaginationToken有:True
    ## PaginationToken無:false
    ## ページ当たりのリソースの上限値は50(デフォルト)で、最大100まで設定可能です。
    ## ResourcesPerPage:上限値
    ## ----------------------------------------------------------------------------------
    while 'PaginationToken' in response and response['PaginationToken']:
        ## PaginationToken値の取得
        token = response['PaginationToken']
        response = resourcegroupstaggingapi_client.get_resources(TagFilters=tag_filters, ResourcesPerPage=1, ResourceTypeFilters = ['workspaces'], PaginationToken=token)
        ## WorkspacesのARNとタグ情報を取得
        workspace_lists = response["ResourceTagMappingList"]
        ## WorkspaceIdの抽出（辞書型）
        workspace_id = [{"WorkspaceId": workspace["ResourceARN"].split("/")[-1]} for workspace in workspace_lists]
        ## WorkspaceIdが空の場合はループを抜けます。
        if str(workspace_id) == '[]':
            break

        print("特定タグ付きWorkspacesの状態を確認します。")
        ## WorkspacesのARNとタグ情報を表示
        print(workspace_lists) ## Debug code
        
        ## WorkspaceIdの抽出
        for workspace in workspace_lists:
            workspace_id = workspace["ResourceARN"].split("/")[-1]

        ## 対象WorkSpacesの状態確認（WorkSpacesの状態確認用関数呼び出し）
        status = describe_workspace(workspace_id)
        ## 関数戻り値の表示
        print(status)
        ## 関数戻り値を配列に格納
        status_list.append(status)

    ## 状態確認したWorkSpaceの合計数を取得
    status_list_num = len(status_list)

    print("状態確認したWorkspace " + "合計:" + str(status_list_num))
    print("------------------------------------------------------")
    ## Workspaceの状態を表示
    for item in status_list:
        print(item)
    print("\n")

    ## Status値がUNHEALTHYのWorkspace情報を取得
    ## in演算子で配列に特定の要素が含まれるか判定します。
    ## 特定の文字列(s) in 元の文字列(status_list)で、元の文字列に特定の文字列が含まれると配列の要素を返します。
    check_in = [s for s in status_list if 'STOPPED' in s] ## Debug
    # check_in = [s for s in status_list if 'UNHEALTHY' in s]

    ## UNHEALTHY状態のWorkspaceの合計数を取得
    check_num = len(check_in)

    ## UNHEALTHY状態のWorkspace情報を格納する配列
    check_str = ""
    check_str = "UNHEALTHY状態のWorkspace " + "合計:" + str(check_num) + "\n"
    check_str += "------------------------------------------------------" + "\n"
    ## UNHEALTHY状態のWorkspace情報を配列に格納
    for i in check_in:
        check_str += i + "\t\n"

    ## UNHEALTHY状態のWorkspaceを表示
    print(check_str)
    
    ## UNHEALTHY状態のWorkspaceが存在する場合はメール通知します。
    if check_num != 0:
        ## 通知設定
        massages = {
            'TopicArn': sns_topic_arn,
            'Subject': alarm_subject,
            'Message': check_str
        }
        print("UNHEALTHY状態のWorkspacesが存在するためメール通知します。")
        sns.publish(**massages)

    return 0

## ----------------------------------------------------------------------------------
## WorkSpacesの状態確認用関数
## ----------------------------------------------------------------------------------
def describe_workspace(workspace_id):
    ## メソッドのオブジェクト化
    results = workspaces_client.describe_workspaces(WorkspaceIds=[workspace_id])
    ## Workspacesの属性値を変数に格納
    result = results['Workspaces']
    ## Workspacesの属性値を取得
    for workspace in result:
        directory_id = workspace['DirectoryId']
        user_name = workspace['UserName']
        state = workspace['State']

    ## Workspacesの状態を返します。
    return f"DirectoryId:{directory_id} WorkspaceId:{workspace_id} UserName:{user_name} State:{state}"
