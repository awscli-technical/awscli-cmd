#!/bin/bash
#
# check_schedule.sh
# 全プロジェクトのジョブネットに設定されたスケジュール関連情報を一括表示する
#
# 実行方法: bash /root/check_schedule.sh
#
# サブシステム番号は下記の SUBSYSTEM 変数で指定する（0〜9、空欄で指定なし）
#
# 出力例:
#   --- PRJ-GRP-ORG/jobnet00 ---
#   starttime 2335
#   execpattern kidoubi-test
#   --- PRJ-GRP-ORG/jobnet01 ---
#   noexecution ON
#
# 検索キーワード:
#   execpattern   - 起動日雛形
#   annuallydate  - 年次日付指定（毎年○月○日）
#   weekday       - 曜日指定
#   dayofweek     - 曜日指定（別形式）
#   starttime     - 起動時刻（HHMM形式）
#   noexecution   - 起動抑止（ON=自動起動しない）
#

# サブシステム番号（0〜9 を指定、空欄の場合は -sys オプションなしで実行）
SUBSYSTEM=""

# サブシステム指定のオプション組み立て
SYS_OPT=""
if [ -n "$SUBSYSTEM" ]; then
  SYS_OPT="-sys $SUBSYSTEM"
  echo "サブシステム: $SUBSYSTEM"
  echo ""
fi

# jobschprint コマンドのパス
JOBSCHPRINT="/opt/FJSVJOBSC/bin/jobschprint"

# 全プロジェクト名を動的に取得して配列に格納
mapfile -t projects < <($JOBSCHPRINT -n -long $SYS_OPT 2>/dev/null | awk '/^Project Name:/{print $3}' | sort -u)

# プロジェクトが取得できなかった場合のエラー処理
if [ ${#projects[@]} -eq 0 ]; then
  echo "ERROR: プロジェクトが取得できませんでした。" >&2
  echo "  - デーモン（jobschd）が起動しているか確認してください。" >&2
  echo "  - サブシステム番号が正しいか確認してください。" >&2
  exit 1
fi

echo "対象プロジェクト数: ${#projects[@]}"
echo ""

# プロジェクトごとにループ
for prj in "${projects[@]}"; do

  # jobschprint -n -long の出力から、対象プロジェクトに属するジョブネット名を抽出
  for net in $($JOBSCHPRINT -n -long $SYS_OPT 2>/dev/null | \
    awk -v p="$prj" '/^Project Name:/{found=($3==p)} found && /^[^ ]/{print $1}'); do

    # ジョブネット定義からスケジュール関連キーワードに一致する行を抽出
    result=$($JOBSCHPRINT -r "$prj/$net" $SYS_OPT 2>/dev/null | \
      grep -E "execpattern|annuallydate|weekday|dayofweek|starttime|noexecution")

    # 結果が空でなければヘッダ付きで表示
    if [ -n "$result" ]; then
      echo "--- $prj/$net ---"
      echo "$result"
    fi

  done
done

exit 0
