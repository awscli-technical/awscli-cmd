#
# check_execpattern.ps1
# 全プロジェクトのジョブネットに設定された起動日雛形（execpattern）を一括確認する
#
# 実行方法: powershell -ExecutionPolicy Bypass -File C:\check_execpattern.ps1
#
# サブシステム番号は下記の $Subsystem 変数で指定する（0〜9、空文字で指定なし）
#
# 出力例: PRJ-GRP-ORG/jobnet00: execpattern kidoubi-test
#

# サブシステム番号（0〜9 を指定、空文字の場合は -sys オプションなしで実行）
$Subsystem = ""

# サブシステム指定のオプション組み立て
$sysOpt = @()
if ($Subsystem -ne "") {
    $sysOpt = @("-sys", $Subsystem)
    Write-Host "サブシステム: $Subsystem"
    Write-Host ""
}

# jobschprint コマンドのパス（環境に合わせて変更すること）
$jobschprint = "C:\Systemwalker\MPWALKER.JM\bin\jobschprint.exe"

# ジョブネット一覧を取得
$allLines = & $jobschprint -n -long @sysOpt 2>$null

# 全プロジェクト名を動的に取得して配列に格納（重複排除）
$projects = @()
foreach ($line in $allLines) {
    if ($line -match "^Project Name:\s+(\S+)") {
        $prjName = $Matches[1]
        if ($projects -notcontains $prjName) {
            $projects += $prjName
        }
    }
}

# プロジェクトが取得できなかった場合のエラー処理
if ($projects.Count -eq 0) {
    Write-Error "ERROR: プロジェクトが取得できませんでした。"
    Write-Error "  - デーモン（jobschd）が起動しているか確認してください。"
    Write-Error "  - サブシステム番号が正しいか確認してください。"
    exit 1
}

# プロジェクトごとにループ
foreach ($prj in $projects) {

    # 対象プロジェクトに属するジョブネット名を抽出
    $inProject = $false
    $nets = @()
    foreach ($line in $allLines) {
        if ($line -match "^Project Name:\s+(\S+)") {
            $inProject = ($Matches[1] -eq $prj)
        } elseif ($inProject -and $line -match "^(\S+)") {
            $nets += $Matches[1]
        }
    }

    # 各ジョブネットの定義に execpattern が含まれるか判定し、該当すれば表示
    foreach ($net in $nets) {
        $output = & $jobschprint -r "$prj/$net" @sysOpt 2>$null
        $match = $output | Select-String "execpattern"
        if ($match) {
            Write-Host "${prj}/${net}: $($match.Line.Trim())"
        }
    }
}
