#!/bin/bash
#
# check_execpattern.sh
# 全プロジェクトのジョブネットに設定された起動日雛形（execpattern）を一括確認する
#
# 実行方法: bash /root/check_execpattern.sh
#
# サブシステム番号は下記の SUBSYSTEM 変数で指定する（0〜9、空欄で指定なし）
#
# 出力例: PRJ-GRP-ORG/jobnet00: execpattern kidoubi-test
#

# サブシステム番号（0〜9 を指定、空欄の場合は -sys オプションなしで実行）
SUBSYSTEM=""

# サブシステム指定のオプション組み立て
SYS_OPT=""
if [ -n "$SUBSYSTEM" ]; then
  SYS_OPT="-sys $SUBSYSTEM"
  echo "サブシステム: $SUBSYSTEM"
  echo ""
fi

# jobschprint コマンドのパス
JOBSCHPRINT="/opt/FJSVJOBSC/bin/jobschprint"

# 全プロジェクト名を動的に取得して配列に格納
mapfile -t projects < <($JOBSCHPRINT -n -long $SYS_OPT 2>/dev/null | awk '/^Project Name:/{print $3}' | sort -u)

# プロジェクトが取得できなかった場合のエラー処理
if [ ${#projects[@]} -eq 0 ]; then
  echo "ERROR: プロジェクトが取得できませんでした。" >&2
  echo "  - デーモン（jobschd）が起動しているか確認してください。" >&2
  echo "  - サブシステム番号が正しいか確認してください。" >&2
  exit 1
fi

# プロジェクトごとにループ
for prj in "${projects[@]}"; do

  # jobschprint -n -long の出力から、対象プロジェクトに属するジョブネット名を抽出
  for net in $($JOBSCHPRINT -n -long $SYS_OPT 2>/dev/null | \
    awk -v p="$prj" '/^Project Name:/{found=($3==p)} found && /^[^ ]/{print $1}'); do

    # ジョブネット定義に execpattern が含まれるか判定し、該当すれば表示
    $JOBSCHPRINT -r "$prj/$net" $SYS_OPT 2>/dev/null | grep -q "execpattern" && \
    echo "$prj/$net: $($JOBSCHPRINT -r "$prj/$net" $SYS_OPT 2>/dev/null | grep 'execpattern')"

  done
done

exit 0
