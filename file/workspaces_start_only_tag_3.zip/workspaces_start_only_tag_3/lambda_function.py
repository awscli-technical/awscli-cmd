## aws-vault exec aws07 --duration 12h
## python-lambda-local -f lambda_handler lambda_function.py event.json -e env.json --timeout 900
## lambda-uploader
import boto3
import os

client = boto3.client('workspaces')

def lambda_handler(event, context):
    ## 環境変数の読み込み
    target_directory_id = os.environ.get('TARGET_DIRECTORY_ID', '')
    target_tag_key      = os.environ.get('TARGET_TAG_KEY', '')
    target_tag_value    = os.environ.get('TARGET_TAG_VALUE', '')
    from_number         = os.environ.get('FROM_NUMBER', '')
    to_number           = os.environ.get('TO_NUMBER', '')
    #print(type(from_number)) ## Debug code
    #print(type(to_number)) ## Debug code
    print("TARGET_DIRECTORY_ID = " + target_directory_id)
    print("TARGET_TAG_KEY = " + target_tag_key)
    print("TARGET_TAG_VALUE = " + target_tag_value)
    print("FROM_NUMBER = " + from_number)
    print("TO_NUMBER = " + to_number)

    ## 文字列型を整数型に変換
    from_num = int(from_number)
    to_num = int(to_number)

    workspaces_client_list = ""
    if target_directory_id == '':
        print("全てのWorkSpacesが対象です。")
        response = client.describe_workspaces()
        workspaces_client_list = response['Workspaces']
        while "NextToken" in response:
            workspaces_client_list.extend(response['Workspaces'])
            response = client.describe_workspaces(NextToken=response['NextToken'])
        #print(workspaces_client_list) ## Debug code
    else:
        print(target_directory_id + "配下のWorkSpacesが対象です。")
        response = client.describe_workspaces(DirectoryId=target_directory_id)
        workspaces_client_list = response['Workspaces']
        while "NextToken" in response:
            workspaces_client_list.extend(response['Workspaces'])
            response = client.describe_workspaces(NextToken=response['NextToken'])
        #print(workspaces_client_list) ## Debug code

    workspaces_range = []
    ## 全WorkSpacesの属性情報からWorkspaceIdを配列に格納します。
    for workspace in  workspaces_client_list:
        workspaces_range.append(workspace['WorkspaceId'])
        #print(workspaces_range) ## Debug code
    #print(workspaces_range) ## Debug code
    ## 配列内の全WorkspaceIdをソートします。
    workspaces_range.sort()
    #print(workspaces_range) ## Debug code

    cnt = 0
    workspaces_range_list = []
    ## ソート済WorkspaceIdの範囲を指定して配列に格納します。
    for tmp_workspace in workspaces_range:
        ## WorkspaceIdの範囲を指定
        if cnt >= from_num and cnt <= to_num:
            print(cnt)
            print(tmp_workspace)
            ## 配列に格納
            workspaces_range_list.append(tmp_workspace)
        cnt += 1
    print("範囲指定されたWorkspaceIdを表示します。")
    print(workspaces_range_list)

    workspaces_target_list = []
    ## 範囲していされたWorkspaceIdを1台ずつ読み出し
    for workspace in workspaces_range_list:
        # print(workspace) ## Debug code
        workspace_id = workspace
        ## workspaceのタグ情報を読み出し
        workspaces_tag = client.describe_tags(ResourceId=workspace_id)
        print("対象状態WorkSpacesの全タグ ............")
        print(workspaces_tag)
        for tag in workspaces_tag.get('TagList'):
            ## タグ情報からタグリストを取得して対象タグが一致するものを配列に格納
            if (tag.get('Key') == target_tag_key) and (tag.get('Value') == target_tag_value):
                workspaces_target_list.append(workspace_id)
                workspaces_target_list.append(tag.get('Key'))
                workspaces_target_list.append(tag.get('Value'))
                print("対象タグを保持しているWorkSpaces ............")
                print("WorkspaceId:" + workspace_id, "target_tag_key:" + tag.get('Key'), "target_tag_value:" + tag.get('Value'))
                rc = start_workspaces(workspace_id)
                if rc == 0:
                    print('WorkSpace "{0}" started successfully.'.format(workspace_id))
                else:
                    print('WorkSpace "{0}" tried to start, but an error occurred while starting.'.format(workspace_id))
            #print(workspaces_target_list) ## Debug code
    ## 戻り値
    return workspaces_target_list

## 対象WorkSpacesの再起動
def start_workspaces(workspace_id):
    execution_result = client.start_workspaces(
        StartWorkspaceRequests = [
            {
                'WorkspaceId': workspace_id
            },
        ]
    )
    failed_requests = execution_result.get('FailedRequests')
    if not failed_requests:
        return 0
    else:
        print('[Error] {0}'.format(failed_requests))
        return 1
