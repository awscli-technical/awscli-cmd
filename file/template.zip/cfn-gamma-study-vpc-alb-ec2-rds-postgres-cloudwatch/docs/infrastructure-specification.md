# インフラストラクチャ構成仕様書

## 概要

| 項目               | 値                                                                               |
| ------------------ | -------------------------------------------------------------------------------- |
| システム名         | gamma                                                                            |
| リージョン         | ap-northeast-1（東京）                                                           |
| 環境               | dev（開発環境）                                                                  |
| IaC ツール         | AWS CloudFormation                                                               |
| 命名プレフィックス | cfn                                                                              |
| デプロイ方式       | S3にテンプレートを格納し、親スタックからネステッドスタックとして各リソースを展開 |

## デプロイ構成

### スタック構成

```
CFn-root-00-s3-cfn-template-stack.yaml   ... テンプレート格納用S3バケット作成
CFn-root-01-parent-stack.yaml            ... 親スタック（全リソースのオーケストレーション）
CFn-param-dev-ap-northeast-1.json        ... 環境パラメータファイル
```

親スタック（`CFn-root-01-parent-stack.yaml`）が各サービスのテンプレートをネステッドスタックとして呼び出す構成。

## ネットワーク構成

### VPC

- **CIDR**: `10.40.0.0/16`
- **Internet Gateway**: VPC にアタッチ

### サブネット構成

3種類のサブネットを3AZ（ap-northeast-1a, 1c, 1d）で展開:

| サブネット種別  | CIDR範囲                                    | 用途                                                 |
| --------------- | ------------------------------------------- | ---------------------------------------------------- |
| Public          | 10.40.10.0/24, 10.40.11.0/24, 10.40.12.0/24 | 踏み台・Webサーバー、IGW経由のインターネットアクセス |
| Private Egress  | 10.40.20.0/24, 10.40.21.0/24, 10.40.22.0/24 | NAT経由で外部通信可能なプライベートサブネット        |
| Private Isolate | 10.40.30.0/24, 10.40.31.0/24, 10.40.32.0/24 | 完全に隔離されたサブネット（DB用）                   |

### セキュリティグループ

| セキュリティグループ | 用途              |
| -------------------- | ----------------- |
| sg-ec2               | EC2インスタンス用 |
| sg-alb               | ALB用             |
| sg-nat               | NAT Gateway用     |
| sg-rds               | RDS用             |
| sg-vpc-endpoint      | VPC Endpoint用    |
| sg-efs               | EFS用             |

### アクセス制御

- MyPC（`14.8.27.129/32`）からのアクセスを許可

## コンピューティング

### EC2インスタンス（有効）

| インスタンス            | サブネット  | OS                | インスタンスタイプ | IP          | 用途           |
| ----------------------- | ----------- | ----------------- | ------------------ | ----------- | -------------- |
| bastion-amazonlinux2023 | Public (1a) | Amazon Linux 2023 | t2.micro           | 10.40.10.10 | 踏み台サーバー |
| web-amazonlinux2023     | Public (1a) | Amazon Linux 2023 | t2.micro           | 10.40.10.11 | Webサーバー    |

- AMI: `ami-05284d16d6b516ace`（固定）
- EBSボリューム: 8GB, gp3
- パブリックIP: 自動割り当て有効

### EC2インスタンス（コメントアウト・未デプロイ）

| インスタンス              | サブネット          | OS                  | インスタンスタイプ | 用途                 |
| ------------------------- | ------------------- | ------------------- | ------------------ | -------------------- |
| bastion-rhel9             | Public (1a)         | RHEL 9              | t2.micro           | 踏み台サーバー       |
| bastion-windowsserver2022 | Public (1a)         | Windows Server 2022 | t2.medium          | 踏み台サーバー       |
| web-amazonlinux2023       | Private Egress (1a) | Amazon Linux 2023   | t2.micro           | Webサーバー          |
| gw-windowsserver2022      | Private Egress (1a) | Windows Server 2022 | t2.medium          | ゲートウェイサーバー |

### キーペア

- EC2接続用キーペア
- 統合マスター用キーペア

## IAM

### ロール

| ロール                | 用途                          |
| --------------------- | ----------------------------- |
| iam-role-ec2          | EC2インスタンスプロファイル用 |
| iam-role-lambda       | Lambda実行用                  |
| iam-role-backup       | AWS Backup用                  |
| iam-role-snowflake-bc | Snowflake連携用               |

### ユーザー/グループ

| 種別               | ユーザー                    | グループ                     | 用途                           |
| ------------------ | --------------------------- | ---------------------------- | ------------------------------ |
| Worker             | iam-user-wk01               | iam-group-wk01               | 作業者用（スイッチロール構成） |
| Integration Master | iam-user-integration-master | iam-group-integration-master | 統合マスター用                 |

## データベース

### RDS（有効）

| 項目               | 値                                      |
| ------------------ | --------------------------------------- |
| エンジン           | PostgreSQL 16.6                         |
| インスタンスクラス | db.t4g.micro                            |
| マスターユーザー   | postgres                                |
| データベース名     | sampledb                                |
| サブネットグループ | Public, Private Egress, Private Isolate |

### Aurora（コメントアウト・未デプロイ）

- Aurora PostgreSQL クラスター構成が定義済み

## ストレージ

### S3バケット

| バケット                            | 用途                             |
| ----------------------------------- | -------------------------------- |
| s3-bucket-cfn-{region}-{account_id} | CloudFormationテンプレート格納用 |
| s3-bucket-{account_id}              | 汎用バケット                     |

## 監視・通知

### SNS

- 通知用トピック（`sns-topic`）

### CloudWatch Alarm

- EC2 CPU使用率アラーム → SNSトピックへ通知

### ログ監視パイプライン

```
CloudWatch Logs → Subscription Filter → Lambda → SNS → Email
```

- `lambda-function-log-notification-processor`: ログフィルタリング・通知処理
- `lambda-function-log-sample-app`: サンプルアプリケーション用ログ出力

## 自動化

### RDS・EC2自動停止

```
EventBridge Rule (スケジュール) → Lambda Function → RDS/EC2 停止
```

- `lambda-function-autostop-resource`: リソース自動停止用Lambda関数

## 未デプロイリソース（コメントアウト）

以下のリソースはテンプレートに定義済みだが、現在はコメントアウトされている:

| カテゴリ           | リソース                     | 備考                                  |
| ------------------ | ---------------------------- | ------------------------------------- |
| ネットワーク       | NAT Gateway                  | Private Egress サブネットの外部通信用 |
| ネットワーク       | VPC Endpoint                 | プライベート接続用                    |
| ロードバランサー   | ALB + ターゲットグループ     | Web層の負荷分散                       |
| コンピューティング | Private Egress EC2           | Web/GWサーバー                        |
| コンピューティング | RHEL9/Windows踏み台          | 追加OS対応                            |
| データベース       | Aurora クラスター            | 高可用性DB                            |
| ストレージ         | EFS                          | 共有ファイルシステム                  |
| バックアップ       | AWS Backup (Vault/Plan)      | RDS/EC2/EFSバックアップ               |
| 運用管理           | SSM Association              | State Manager                         |
| 運用管理           | SSM Maintenance Window       | 定期メンテナンス                      |
| 運用管理           | SSM Automation + EventBridge | EC2自動起動/停止                      |

## 命名規則

すべてのリソースは以下のパターンで命名:

```
{iac}-{system}-{env}-{service}-{detail}
例: cfn-gamma-dev-ec2-instance-ap-northeast-1a-bastion-amazonlinux2023
```

| プレースホルダ | 値（dev環境）                       |
| -------------- | ----------------------------------- |
| {iac}          | cfn                                 |
| {system}       | gamma                               |
| {env}          | dev                                 |
| {service}      | リソース種別（vpc, ec2, rds, etc.） |
| {detail}       | リソース固有の識別子                |

## アーキテクチャの設計方針

1. **コスト最適化**: 開発環境のため、NAT Gateway や ALB はコメントアウトして費用を抑制
2. **自動停止**: Lambda + EventBridge でRDS・EC2を自動停止し、開発環境のランニングコストを削減
3. **ログ監視**: CloudWatch Logs → Lambda → SNS → Email のパイプラインでログフィルタリング・通知
4. **拡張性**: 本番環境ではコメントアウト部分を有効化することで、NAT/ALB/VPC Endpoint/マルチAZ構成に拡張可能
5. **マルチ環境対応**: パラメータファイルを環境ごとに用意し、同一テンプレートで dev/stg/prd/poc を管理
6. **ネステッドスタック**: サービスごとにテンプレートを分割し、管理性・再利用性を向上
