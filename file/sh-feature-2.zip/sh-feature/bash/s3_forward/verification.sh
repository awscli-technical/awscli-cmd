HOME_DIR="/home/iac/work/git/sh/bash/s3_forward"

rm -rf "${HOME_DIR}/verification/*"
rm -rf "${HOME_DIR}/log/*"

# CSVファイル作成 /home/iac/work/git/sh/verification/csv/testNNNN.csv
tee make.sh <<'EOF' >/dev/null
HOME_DIR="/home/iac/work/git/sh/bash/s3_forward"
if [[ ! -d ${HOME_DIR}/verification/csv ]]; then
    mkdir -p ${HOME_DIR}/verification/csv
    mkdir -p ${HOME_DIR}/verification/csv/sub
fi
for i in $(seq -f '%04g' 0 19); do
    dd if=/dev/zero of=${HOME_DIR}/verification/csv/test${i}.csv bs=1M count=1
done
for ii in $(seq -f '%04g' 0 19); do
    dd if=/dev/zero of=${HOME_DIR}/verification/csv/sub/test${ii}.csv bs=1M count=1
done
EOF
bash make.sh

# 保管ディレクトリ作成(世代管理有り) ${HOME_DIR}/verification/YYYYMMDD
tee make.sh <<'EOF' >/dev/null
HOME_DIR="/home/iac/work/git/sh/bash/s3_forward"
max=21
for ((i = 1; i < $max; i++)); do
    date=$(date --date "$i days ago" "+%Y%m%d")
    mkdir -p ${HOME_DIR}/verification/$date/sub
    touch -t ${date}0000 ${HOME_DIR}/verification/$date
    for ii in $(seq -f '%04g' 0 9); do
        dd if=/dev/zero of=${HOME_DIR}/verification/$date/test${ii}.csv bs=1M count=1
        touch -t ${date}0000 ${HOME_DIR}/verification/$date/test${ii}.csv
    done
    for iii in $(seq -f '%04g' 0 9); do
        dd if=/dev/zero of=${HOME_DIR}/verification/$date/sub/test${iii}.csv bs=1M count=1
        touch -t ${date}0000 ${HOME_DIR}/verification/$date/sub/test${iii}.csv
    done
done
EOF
bash make.sh

# ログファイル作成 ${HOME_DIR}/s3_forwarding_YYYYMMDD-120000.log
tee make.sh <<'EOF' >/dev/null
HOME_DIR="/home/iac/work/git/sh/bash/s3_forward"
max=32
mkdir -p ${HOME_DIR}/log
for ((i=1; i < $max; i++)); do
    date=`date --date "$i days ago" "+%Y%m%d"`
    touch ${HOME_DIR}/log/s3_forwarding_${date}-120000.log
    dd if=/dev/zero of=${HOME_DIR}/log/s3_forwarding_${date}-120000.log bs=1M count=1
    touch -t ${date}1200 ${HOME_DIR}/log/s3_forwarding_${date}-120000.log
done
EOF
bash make.sh
