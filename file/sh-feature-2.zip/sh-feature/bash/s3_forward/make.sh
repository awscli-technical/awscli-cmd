HOME_DIR="/home/iac/work/git/sh/bash/s3_forward"
max=32
mkdir -p ${HOME_DIR}/log
for ((i=1; i < $max; i++)); do
    date=`date --date "$i days ago" "+%Y%m%d"`
    touch ${HOME_DIR}/log/s3_forwarding_${date}-120000.log
    dd if=/dev/zero of=${HOME_DIR}/log/s3_forwarding_${date}-120000.log bs=1M count=1
    touch -t ${date}1200 ${HOME_DIR}/log/s3_forwarding_${date}-120000.log
done
