#!/bin/bash
####################################################################################################
#    プログラム名  :  特定ディレクトリ配下にあるファイルをS3 Bucketに転送します。
#    ファイル名    :  s3_backup.sh
#    作成者        :  tmky development)nagai takashi
#    作成日        :  2025/02/01
#    備考          :  このスクリプトはAWSの認証処理がされていることが前提です。
#    変更履歴      :
#
#    日付        更新者    内容
#    2025/02/01  nagai     新規作成
#
#    引数          :  $1()
#    戻り値        :  0(正常)
#                  :  1(異常)
####################################################################################################
##################################################
# 関数定義
##################################################
#-------------------------------------------------
# 関数名  :  エラーハンドリング
# 機能    :  実行結果の戻り値と正常系・異常系メッセージを受取ります。
#            実行結果の戻り値が0の場合は正常系メッセージを表示します。
#            実行結果の戻り値が0以外の場合は異常系メッセージを表示します。
# 引数    :  $1(コマンドの戻り値)
#            $2(正常系メッセージ)
#            $3(異常系メッセージ)
#-------------------------------------------------
function process_error_handling() {
    if [[ "$1" -eq 0 ]]; then
        # 正常系メッセージをコンソールとログファイルに出力して戻り値0を返す
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $2" 2>&1 | tee -a "${LOG}"
        return 0
    else
        # システムログにエラーを通知
        logger -i -p user.err "[${HOST_NAME}] Monitoring notification code [${SCRIPT_NAME}.sh] Error code [$3]"
        # 異常系メッセージをコンソールとログファイルに出力して戻り値1を返す
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] $3" 2>&1 | tee -a "${LOG}"
        return 1
    fi
}

#-------------------------------------------------
# 関数名  :  ファイル転送
# 機能    :  特定ディレクトリ配下にあるファイルをS3 Bucketに転送します。
# 引数    :
#-------------------------------------------------
function process_s3_forwarding() {
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_S3_FORWARDING}" 2>&1 | tee -a "${LOG}"
    ${S3_FORWARDING_CMD} 2>&1 | tee -a "${LOG}"
    CMD_RC=${PIPESTATUS[0]}
    # エラーハンドリング関数呼出
    process_error_handling "${CMD_RC}" "${MSG_SUCCESS_S3_FORWARDING}" "${MSG_FAILURE_S3_FORWARDING}"
}

#-------------------------------------------------
# 関数名  :  ファイル移動
# 機能    :  転送済ファイルを日付ディレクトリを作成して移動させます。
# 引数    :
#-------------------------------------------------
function process_move() {
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_MOVE}" 2>&1 | tee -a "${LOG}"
    if [[ ! -d ./verification/${DATE} ]]; then
        # ログ格納ディレクトリが存在しない場合は作成
        mkdir ./verification/${DATE}
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_MAKE_DATE_DIRECTORY}" 2>&1 | tee -a "${LOG}"
    fi
    # 特定ディレクトリ配下のファイル数取得
    file_cnt=$(find ./verification/csv -type f | wc -l)
    if [[ $file_cnt -gt 0 ]]; then
        # ファイルが存在する場合は移動処理を継続
        mv ./verification/csv/* ./verification/${DATE} 2>&1 | tee -a "${LOG}"
        CMD_RC=${PIPESTATUS[0]}
        # エラーハンドリング関数呼出
        process_error_handling "${CMD_RC}" "${MSG_SUCCESS_MOVE}" "${MSG_FAILURE_MOVE}"
    else
        # ファイルが存在しない場合は移動処理を中断して通知
        echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_FILE_NOT_EXSIST}" 2>&1 | tee -a "${LOG}"
    fi
}

#-------------------------------------------------
# 関数名  :  ファイル世代管理
# 機能    :  保管要件を過ぎたディレクトリを削除します。
# 引数    :
#-------------------------------------------------
function process_gen_mgmt() {
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_GEN_MGMT}" 2>&1 | tee -a "${LOG}"
    cnt=0
    # ファイル保管ディレクトリの年月日を抜き出し降順に配列に格納
    array_date=($(find ./verification/ -type d | grep -oE '[0-9]{8}' | sort -r | uniq))
    for i in "${array_date[@]}"; do
        if [[ $cnt -lt ${SAVE_NUM} ]]; then
            echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_SAVE_GEN_MGMT} ./verification/$i" 2>&1 | tee -a "${LOG}"
        else
            echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_DELETE_GEN_MGMT} ./verification/$i" 2>&1 | tee -a "${LOG}"
            rm -rf ./verification/$i
            CMD_RC="$?"
            # エラーハンドリング関数呼出
            process_error_handling "${CMD_RC}" "${MSG_SUCCESS_GEN_MGMT}" "${MSG_FAILURE_GEN_MGMT}"
        fi
        cnt=$(expr $cnt + 1)
    done
}

##################################################
# 前処理
##################################################
#-------------------------------------------------
# 共通パラメータ取得
#-------------------------------------------------
COMMON_CONF="conf/common.conf"
. "${COMMON_CONF}"

##-----------------------------------------------
## 共通パラメータ取得確認(デバック用途)
##-----------------------------------------------
param=(
    DATE="$DATE"
    SCRIPT_NAME="$SCRIPT_NAME"
    LOG_DATE="$LOG_DATE"
    LOG_PATH="$LOG_PATH"
    LOG="$LOG"
    LOG_DELETE="$LOG_DELETE"
    HOST_NAME="$HOST_NAME"
    EXECUTE_USER="$EXECUTE_USER"
    MSG_SUCCESS_S3_FORWARDING="$MSG_SUCCESS_S3_FORWARDING"
    MSG_FAILURE_S3_FORWARDING="$MSG_FAILURE_S3_FORWARDING"
    MSG_LOG_DIRECTORY_NOT_EXIST="$MSG_LOG_DIRECTORY_NOT_EXIST"
    MSG_EXECUTE_USER_NOT_EXIST="$MSG_EXECUTE_USER_NOT_EXIST"
    MSG_SUCCESS_LOG_DELETE="$MSG_SUCCESS_LOG_DELETE"
    MSG_FAILURE_LOG_DELETE="$MSG_FAILURE_LOG_DELETE"
    MSG_START_THIS="$MSG_START_THIS"
    MSG_SUCCESS_END_THIS="$MSG_SUCCESS_END_THIS"
    MSG_FAILURE_END_THIS="$MSG_FAILURE_END_THIS"
    SRC_LOCAL_DIR="$SRC_LOCAL_DIR"
    DST_S3_BUCKET="$DST_S3_BUCKET"
    S3_FORWARDING_CMD="$S3_FORWARDING_CMD"
)

# for i in "${param[@]}"; do
#     echo $i
# done

#-------------------------------------------------
# ログ格納ディレクトリ存在確認
#-------------------------------------------------
if [[ ! -d log ]]; then
    # ログ格納ディレクトリが存在しない場合は作成
    mkdir log
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_MAKE_LOG_DIRECTORY}" 2>&1 | tee -a "${LOG}"
fi

#-------------------------------------------------
# 実行ユーザ存在確認
#-------------------------------------------------
WHOAMI=""
WHOAMI=$(cat /etc/passwd | grep ^${EXECUTE_USER} | awk -F : '{print $1}')
if [[ ! "${WHOAMI}" ]]; then
    # 実行ユーザが存在しない場合は異常終了
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_EXECUTE_USER_NOT_EXIST}" 2>&1 | tee -a "${LOG}"
    exit 1
fi

# 全体処理開始
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_START_THIS}" 2>&1 | tee -a "${LOG}"

##################################################
# 主処理
##################################################
# ファイル転送関数呼出
process_s3_forwarding
FUNC_RC="$?"
if [[ "${FUNC_RC}" != 0 ]]; then
    echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_FAILURE_END_THIS}" 2>&1 | tee -a "${LOG}"
    # 異常終了
    exit 1
fi

# ファイル移動関数呼出
process_move

# ファイル世代管理関数呼出
process_gen_mgmt

##################################################
# 後処理
##################################################
#-------------------------------------------------
# 特定日数を経過したログの削除
#-------------------------------------------------
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${LOG_DELETE} 日以上経過したログの削除を開始します。" 2>&1 | tee -a "${LOG}"
find ./log -mtime +${LOG_DELETE} -name *.log | xargs rm -f
CMD_RC=$(echo $?)
# エラーハンドリング関数呼出
process_error_handling "${CMD_RC}" "${MSG_SUCCESS_LOG_DELETE}" "${MSG_FAILURE_LOG_DELETE}"

# 全体処理正常終了
echo "$(date +"%Y/%m/%d %H:%M:%S")" "[${HOST_NAME}] ${MSG_SUCCESS_END_THIS}" 2>&1 | tee -a "${LOG}"
aws sns publish --topic-arn "${SNS_TOPIC_ARN}" --subject "${SNS_SUB_SUCCESS}" --message "${MSG_SUCCESS_END_THIS}" 2>&1 | tee -a "${LOG}"

exit 0
